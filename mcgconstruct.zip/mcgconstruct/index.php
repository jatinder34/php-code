<!DOCTYPE html>
<html>
<head>
  <title>MCG</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">
<link href="css/style.css" rel="stylesheet">
</head>
<body>
<section class="head_back">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="logo">
					<img src="images/logo-adress.png" class="lo_img img-responsive">
				</div>
			</div>
		</div>
	</div>
</section>

<section class="image_back">
	<div class="container">
		<div class="row">
			<div class="col-md-6 col-sm-6">
				<div class="men_text_right">
					<p>MCG Construction, LLC is a commercial General Contractor and Construction Manager that operates in the New York City metropolitan area.<br><br>
<h4>For further information please contact us at:</h4></p>
<ul class="un_ord">
<li>MCG Construction, LLC</li>
<li>1250 Waters Place – PH1</li>
<li>Bronx, NY 10461</li>
<li>347-547-7067 Tel.</li>
<li>347-547-7068 Fax</li>
<li>info@mcgconstruct.com</li>
				</div>
			</div>
			<div class="col-md-6 col-sm-6">
				<div class="men_text_right">
					<h1>Contact Us</h1>
					<?php
						if(isset($_POST['email'])){
							$admin_email = "jatinderkumar0550@gmail.com";
							$name = $_POST['name'];
							$email = $_POST['email'];
							$phone = $_POST['phone'];
							$company = $_POST['company'];
							$description = $_POST['description'];
							$headers .= 'From: ' . strip_tags($_POST['email']) . '\r\n';
							$headers .= 'MIME-Version: 1.0\r\n';
							$headers .= 'Content-Type: text/html; charset=ISO-8859-1\r\n';
							$message .= '<html><body>';
							$message .= '<table rules="all" style="border-color: #666;" cellpadding="10">';
							$message .= '<tr><td><strong>Name:</strong> </td><td>' . strip_tags($_POST['name']) . '</td></tr>';
							$message .= '<tr><td><strong>Email:</strong> </td><td>' . strip_tags($_POST['email']) . '</td></tr>';
							$message .= '<tr><td><strong>Phone Number:</strong> </td><td>' . strip_tags($_POST['phone']) . '</td></tr>';
							$message .= '<tr><td><strong>Company:</strong> </td><td>' . $_POST['company'] . '</td></tr>';
							$message .= '<tr><td><strong>Description:</strong> </td><td>' . htmlentities($_POST['description']) . '</td></tr>';
							$message .= '</table>';
							$message .= '</body></html>';
							$mail = mail($admin_email, $subject, $message, $headers);
							if($mail){
								echo "Thanku";
							}
							else{
								echo "sorry";
							}
						}
						
					?>
					<form class="rad_ius" method="post" action="index.php">
    <div class="form-group">
      <input type="text" class="form-control" id="pwd" placeholder="Name" name="name">
    </div>
    <div class="form-group">
      <input type="text" class="form-control" id="pwd" placeholder="Email" name="email">
    </div>
	    <div class="form-group">
      <input type="text" class="form-control" id="pwd" placeholder="Phone Number" name="phone">
    </div>
	    <div class="form-group">
      <input type="text" class="form-control" id="pwd" placeholder="Company Name" name="company">
    </div>
	<div class="form-group">
      <textarea class="form-control" rows="5" id="comment" placeholder="Description Box" name="description"></textarea>
    </div>
    <button type="submit" class="btn btn-default haes" name="submit">Submit</button>
  </form>
				</div>
			</div>
		</div>
	</div>
</section>
<section class="co_py_background">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<div class="copy_right">
					<p>poerwd by @2017</P>
				</div>
			</div>
		</div>
	</div>
</section>
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
</body>
</html>
