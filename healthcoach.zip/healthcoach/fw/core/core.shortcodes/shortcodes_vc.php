<?php
if (is_admin() 
		|| (isset($_GET['vc_editable']) && $_GET['vc_editable']=='true' )
		|| (isset($_GET['vc_action']) && $_GET['vc_action']=='vc_inline')
	) {
	require_once HEALTHCOACH_FW_PATH . 'core/core.shortcodes/shortcodes_vc_classes.php';
}

// Width and height params
if ( !function_exists( 'healthcoach_vc_width' ) ) {
	function healthcoach_vc_width($w='') {
		return array(
			"param_name" => "width",
			"heading" => esc_html__("Width", 'healthcoach'),
			"description" => wp_kses_data( __("Width of the element", 'healthcoach') ),
			"group" => esc_html__('Size &amp; Margins', 'healthcoach'),
			"value" => $w,
			"type" => "textfield"
		);
	}
}
if ( !function_exists( 'healthcoach_vc_height' ) ) {
	function healthcoach_vc_height($h='') {
		return array(
			"param_name" => "height",
			"heading" => esc_html__("Height", 'healthcoach'),
			"description" => wp_kses_data( __("Height of the element", 'healthcoach') ),
			"group" => esc_html__('Size &amp; Margins', 'healthcoach'),
			"value" => $h,
			"type" => "textfield"
		);
	}
}

// Load scripts and styles for VC support
if ( !function_exists( 'healthcoach_shortcodes_vc_scripts_admin' ) ) {
	//add_action( 'admin_enqueue_scripts', 'healthcoach_shortcodes_vc_scripts_admin' );
	function healthcoach_shortcodes_vc_scripts_admin() {
		// Include CSS 
		wp_enqueue_style ( 'shortcodes_vc_admin-style', healthcoach_get_file_url('shortcodes/theme.shortcodes_vc_admin.css'), array(), null );
		// Include JS
		wp_enqueue_script( 'shortcodes_vc_admin-script', healthcoach_get_file_url('core/core.shortcodes/shortcodes_vc_admin.js'), array('jquery'), null, true );
	}
}

// Load scripts and styles for VC support
if ( !function_exists( 'healthcoach_shortcodes_vc_scripts_front' ) ) {
	//add_action( 'wp_enqueue_scripts', 'healthcoach_shortcodes_vc_scripts_front' );
	function healthcoach_shortcodes_vc_scripts_front() {
		if (healthcoach_vc_is_frontend()) {
			// Include CSS 
			wp_enqueue_style ( 'shortcodes_vc_front-style', healthcoach_get_file_url('shortcodes/theme.shortcodes_vc_front.css'), array(), null );
			// Include JS
			wp_enqueue_script( 'shortcodes_vc_front-script', healthcoach_get_file_url('core/core.shortcodes/shortcodes_vc_front.js'), array('jquery'), null, true );
			wp_enqueue_script( 'shortcodes_vc_theme-script', healthcoach_get_file_url('shortcodes/theme.shortcodes_vc_front.js'), array('jquery'), null, true );
		}
	}
}

// Add init script into shortcodes output in VC frontend editor
if ( !function_exists( 'healthcoach_shortcodes_vc_add_init_script' ) ) {
	//add_filter('healthcoach_shortcode_output', 'healthcoach_shortcodes_vc_add_init_script', 10, 4);
	function healthcoach_shortcodes_vc_add_init_script($output, $tag='', $atts=array(), $content='') {
		if ( (isset($_GET['vc_editable']) && $_GET['vc_editable']=='true') && (isset($_POST['action']) && $_POST['action']=='vc_load_shortcode')
				&& ( isset($_POST['shortcodes'][0]['tag']) && $_POST['shortcodes'][0]['tag']==$tag )
		) {
			if (healthcoach_strpos($output, 'healthcoach_vc_init_shortcodes')===false) {
				$id = "healthcoach_vc_init_shortcodes_".str_replace('.', '', mt_rand());
				// Attention! This code will be appended in the shortcode's output
				// to init shortcode after it inserted in the page in the VC Frontend editor
				$holder = 'script';
				$output .= '<'.trim($holder).' id="'.esc_attr($id).'">
						try {
							healthcoach_init_post_formats();
							healthcoach_init_shortcodes(jQuery("body").eq(0));
							healthcoach_scroll_actions();
						} catch (e) { };
					</'.trim($holder).'>';
			}
		}
		return $output;
	}
}

// Return vc_param value
if ( !function_exists( 'healthcoach_get_vc_param' ) ) {
	function healthcoach_get_vc_param($prm) {
		return healthcoach_storage_get_array('vc_params', $prm);
	}
}

// Set vc_param value
if ( !function_exists( 'healthcoach_set_vc_param' ) ) {
	function healthcoach_set_vc_param($prm, $val) {
		healthcoach_storage_set_array('vc_params', $prm, $val);
	}
}


/* Theme setup section
-------------------------------------------------------------------- */

if ( !function_exists( 'healthcoach_shortcodes_vc_theme_setup' ) ) {
	//if ( healthcoach_vc_is_frontend() )
	if ( (isset($_GET['vc_editable']) && $_GET['vc_editable']=='true') || (isset($_GET['vc_action']) && $_GET['vc_action']=='vc_inline') )
		add_action( 'healthcoach_action_before_init_theme', 'healthcoach_shortcodes_vc_theme_setup', 20 );
	else
		add_action( 'healthcoach_action_after_init_theme', 'healthcoach_shortcodes_vc_theme_setup' );
	function healthcoach_shortcodes_vc_theme_setup() {

		// Add/Remove params in the standard VC shortcodes

		// Add color scheme
		$scheme = array(
					"param_name" => "scheme",
					"heading" => esc_html__("Color scheme", 'healthcoach'),
					"description" => wp_kses_data( __("Select color scheme for this block", 'healthcoach') ),
					"group" => esc_html__('Color scheme', 'healthcoach'),
					"class" => "",
					"value" => array_flip(healthcoach_get_list_color_schemes(true)),
					"type" => "dropdown"
		);
		vc_add_param("vc_row", $scheme);
		vc_add_param("vc_row_inner", $scheme);
		vc_add_param("vc_column", $scheme);
		vc_add_param("vc_column_inner", $scheme);
		vc_add_param("vc_column_text", $scheme);

		// Add param 'inverse'
		vc_add_param("vc_row", array(
					"param_name" => "inverse",
					"heading" => esc_html__("Inverse colors", 'healthcoach'),
					"description" => wp_kses_data( __("Inverse all colors of this block", 'healthcoach') ),
					"group" => esc_html__('Color scheme', 'healthcoach'),
					"class" => "",
					"std" => "no",
					"value" => array(esc_html__('Inverse colors', 'healthcoach') => 'yes'),
					"type" => "checkbox"
		));

		// Add custom params to the VC shortcodes
		add_filter( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, 'healthcoach_shortcodes_vc_add_params_classes', 10, 3 );

		if (healthcoach_shortcodes_is_used() && class_exists('HEALTHCOACH_VC_ShortCodeSingle')) {

			// Set VC as main editor for the theme
			vc_set_as_theme( true );
			
			// Enable VC on follow post types
			vc_set_default_editor_post_types( array('page', 'team') );
			
			// Load scripts and styles for VC support
			add_action( 'wp_enqueue_scripts',		'healthcoach_shortcodes_vc_scripts_front');
			add_action( 'admin_enqueue_scripts',	'healthcoach_shortcodes_vc_scripts_admin' );

			// Add init script into shortcodes output in VC frontend editor
			add_filter('healthcoach_shortcode_output', 'healthcoach_shortcodes_vc_add_init_script', 10, 4);

			healthcoach_storage_set('vc_params', array(
				
				// Common arrays and strings
				'category' => esc_html__("ThemeREX shortcodes", 'healthcoach'),
			
				// Current element id
				'id' => array(
					"param_name" => "id",
					"heading" => esc_html__("Element ID", 'healthcoach'),
					"description" => wp_kses_data( __("ID for the element", 'healthcoach') ),
					"group" => esc_html__('ID &amp; Class', 'healthcoach'),
					"value" => "",
					"type" => "textfield"
				),
			
				// Current element class
				'class' => array(
					"param_name" => "class",
					"heading" => esc_html__("Element CSS class", 'healthcoach'),
					"description" => wp_kses_data( __("CSS class for the element", 'healthcoach') ),
					"group" => esc_html__('ID &amp; Class', 'healthcoach'),
					"value" => "",
					"type" => "textfield"
				),

				// Current element animation
				'animation' => array(
					"param_name" => "animation",
					"heading" => esc_html__("Animation", 'healthcoach'),
					"description" => wp_kses_data( __("Select animation while object enter in the visible area of page", 'healthcoach') ),
					"group" => esc_html__('ID &amp; Class', 'healthcoach'),
					"class" => "",
					"value" => array_flip(healthcoach_get_sc_param('animations')),
					"type" => "dropdown"
				),
			
				// Current element style
				'css' => array(
					"param_name" => "css",
					"heading" => esc_html__("CSS styles", 'healthcoach'),
					"description" => wp_kses_data( __("Any additional CSS rules (if need)", 'healthcoach') ),
					"group" => esc_html__('ID &amp; Class', 'healthcoach'),
					"class" => "",
					"value" => "",
					"type" => "textfield"
				),
			
				// Margins params
				'margin_top' => array(
					"param_name" => "top",
					"heading" => esc_html__("Top margin", 'healthcoach'),
					"description" => wp_kses_data( __("Margin above this shortcode", 'healthcoach') ),
					"group" => esc_html__('Size &amp; Margins', 'healthcoach'),
					"std" => "inherit",
					"value" => array_flip(healthcoach_get_sc_param('margins')),
					"type" => "dropdown"
				),
			
				'margin_bottom' => array(
					"param_name" => "bottom",
					"heading" => esc_html__("Bottom margin", 'healthcoach'),
					"description" => wp_kses_data( __("Margin below this shortcode", 'healthcoach') ),
					"group" => esc_html__('Size &amp; Margins', 'healthcoach'),
					"std" => "inherit",
					"value" => array_flip(healthcoach_get_sc_param('margins')),
					"type" => "dropdown"
				),
			
				'margin_left' => array(
					"param_name" => "left",
					"heading" => esc_html__("Left margin", 'healthcoach'),
					"description" => wp_kses_data( __("Margin on the left side of this shortcode", 'healthcoach') ),
					"group" => esc_html__('Size &amp; Margins', 'healthcoach'),
					"std" => "inherit",
					"value" => array_flip(healthcoach_get_sc_param('margins')),
					"type" => "dropdown"
				),
				
				'margin_right' => array(
					"param_name" => "right",
					"heading" => esc_html__("Right margin", 'healthcoach'),
					"description" => wp_kses_data( __("Margin on the right side of this shortcode", 'healthcoach') ),
					"group" => esc_html__('Size &amp; Margins', 'healthcoach'),
					"std" => "inherit",
					"value" => array_flip(healthcoach_get_sc_param('margins')),
					"type" => "dropdown"
				)
			) );
			
			// Add theme-specific shortcodes
			do_action('healthcoach_action_shortcodes_list_vc');

		}
	}
}

// Add params in the standard VC shortcodes
if ( !function_exists( 'healthcoach_shortcodes_vc_add_params_classes' ) ) {
	//Handler of the add_filter( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG,				'healthcoach_shortcodes_vc_add_params_classes', 10, 3 );
	function healthcoach_shortcodes_vc_add_params_classes($classes, $sc, $atts) {
		if (in_array($sc, array('vc_row', 'vc_row_inner', 'vc_column', 'vc_column_inner', 'vc_column_text'))) {
			if (!empty($atts['scheme']) && !healthcoach_param_is_off($atts['scheme']) && !healthcoach_param_is_inherit($atts['scheme']))
				$classes .= ($classes ? ' ' : '') . 'scheme_' . $atts['scheme'];
		}
		if (in_array($sc, array('vc_row'))) {
			if (!empty($atts['inverse']) && !healthcoach_param_is_off($atts['inverse']))
				$classes .= ($classes ? ' ' : '') . 'inverse_colors';
		}
		return $classes;
	}
}
?>