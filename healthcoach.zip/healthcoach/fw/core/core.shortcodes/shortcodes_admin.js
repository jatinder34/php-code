// Init scripts
jQuery(document).ready(function(){
	"use strict";
	
	// Settings and constants
	HEALTHCOACH_STORAGE['shortcodes_delimiter'] = ',';		// Delimiter for multiple values
	HEALTHCOACH_STORAGE['shortcodes_popup'] = null;		// Popup with current shortcode settings
	HEALTHCOACH_STORAGE['shortcodes_current_idx'] = '';	// Current shortcode's index
	HEALTHCOACH_STORAGE['shortcodes_tab_clone_tab'] = '<li id="healthcoach_shortcodes_tab_{id}" data-id="{id}"><a href="#healthcoach_shortcodes_tab_{id}_content"><span class="iconadmin-{icon}"></span>{title}</a></li>';
	HEALTHCOACH_STORAGE['shortcodes_tab_clone_content'] = '';

	// Shortcode selector - "change" event handler - add selected shortcode in editor
	jQuery('body').on('change', ".sc_selector", function() {
		"use strict";
		HEALTHCOACH_STORAGE['shortcodes_current_idx'] = jQuery(this).find(":selected").val();
		if (HEALTHCOACH_STORAGE['shortcodes_current_idx'] == '') return;
		var sc = healthcoach_clone_object(HEALTHCOACH_SHORTCODES_DATA[HEALTHCOACH_STORAGE['shortcodes_current_idx']]);
		var hdr = sc.title;
		var content = "";
		try {
			content = tinyMCE.activeEditor ? tinyMCE.activeEditor.selection.getContent({format : 'raw'}) : jQuery('#wp-content-editor-container textarea').selection();
		} catch(e) {};
		if (content) {
			for (var i in sc.params) {
				if (i == '_content_') {
					sc.params[i].value = content;
					break;
				}
			}
		}
		var html = (!healthcoach_empty(sc.desc) ? '<p>'+sc.desc+'</p>' : '')
			+ healthcoach_shortcodes_prepare_layout(sc);


		// Show Dialog popup
		HEALTHCOACH_STORAGE['shortcodes_popup'] = healthcoach_message_dialog(html, hdr,
			function(popup) {
				"use strict";
				healthcoach_options_init(popup);
				popup.find('.healthcoach_options_tab_content').css({
					maxHeight: jQuery(window).height() - 300 + 'px',
					overflow: 'auto'
				});
			},
			function(btn, popup) {
				"use strict";
				if (btn != 1) return;
				var sc = healthcoach_shortcodes_get_code(HEALTHCOACH_STORAGE['shortcodes_popup']);
				if (tinyMCE.activeEditor) {
					if ( !tinyMCE.activeEditor.isHidden() )
						tinyMCE.activeEditor.execCommand( 'mceInsertContent', false, sc );
					else
						send_to_editor(sc);
				} else
					send_to_editor(sc);
			});

		// Set first item active
		jQuery(this).get(0).options[0].selected = true;

		// Add new child tab
		HEALTHCOACH_STORAGE['shortcodes_popup'].find('.healthcoach_shortcodes_tab').on('tabsbeforeactivate', function (e, ui) {
			if (ui.newTab.data('id')=='add') {
				healthcoach_shortcodes_add_tab(ui.newTab);
				e.stopImmediatePropagation();
				e.preventDefault();
				return false;
			}
		});

		// Delete child tab
		HEALTHCOACH_STORAGE['shortcodes_popup'].find('.healthcoach_shortcodes_tab > ul').on('click', '> li+li > a > span', function (e) {
			var tab = jQuery(this).parents('li');
			var idx = tab.data('id');
			if (parseInt(idx) > 1) {
				if (tab.hasClass('ui-state-active')) {
					tab.prev().find('a').trigger('click');
				}
				tab.parents('.healthcoach_shortcodes_tab').find('.healthcoach_options_tab_content').eq(idx).remove();
				tab.remove();
				e.preventDefault();
				return false;
			}
		});

		return false;
	});

});



// Return result code
//------------------------------------------------------------------------------------------
function healthcoach_shortcodes_get_code(popup) {
	HEALTHCOACH_STORAGE['sc_custom'] = '';
	
	var sc_name = HEALTHCOACH_STORAGE['shortcodes_current_idx'];
	var sc = HEALTHCOACH_SHORTCODES_DATA[sc_name];
	var tabs = popup.find('.healthcoach_shortcodes_tab > ul > li');
	var decor = !healthcoach_isset(sc.decorate) || sc.decorate;
	var rez = '[' + sc_name + healthcoach_shortcodes_get_code_from_tab(popup.find('#healthcoach_shortcodes_tab_0_content').eq(0)) + ']';
	if (healthcoach_isset(sc.children)) {
		if (HEALTHCOACH_STORAGE['sc_custom']!='no') {
			var decor2 = !healthcoach_isset(sc.children.decorate) || sc.children.decorate;
			for (var i=0; i<tabs.length; i++) {
				var tab = tabs.eq(i);
				var idx = tab.data('id');
				if (isNaN(idx) || parseInt(idx) < 1) continue;
				var content = popup.find('#healthcoach_shortcodes_tab_' + idx + '_content').eq(0);
				rez += (decor2 ? '\n\t' : '') + '[' + sc.children.name + healthcoach_shortcodes_get_code_from_tab(content) + ']';	// + (decor2 ? '\n' : '');
				if (healthcoach_isset(sc.children.container) && sc.children.container) {
					if (content.find('[data-param="_content_"]').length > 0) {
						rez += content.find('[data-param="_content_"]').val();
					}
					rez += 
						//(decor2 ? '\t' : '') + 
						'[/' + sc.children.name + ']'
						// + (decor ? '\n' : '')
						;
				}
			}
		}
	} else if (healthcoach_isset(sc.container) && sc.container && popup.find('#healthcoach_shortcodes_tab_0_content [data-param="_content_"]').length > 0) {
		rez += popup.find('#healthcoach_shortcodes_tab_0_content [data-param="_content_"]').val();
	}
	if (healthcoach_isset(sc.container) && sc.container || healthcoach_isset(sc.children))
		rez += 
			(healthcoach_isset(sc.children) && decor && HEALTHCOACH_STORAGE['sc_custom']!='no' ? '\n' : '')
			+ '[/' + sc_name + ']';
	return rez;
}

// Collect all parameters from tab into string
function healthcoach_shortcodes_get_code_from_tab(tab) {
	var rez = ''
	var mainTab = tab.attr('id').indexOf('tab_0') > 0;
	tab.find('[data-param]').each(function () {
		var field = jQuery(this);
		var param = field.data('param');
		if (!field.parents('.healthcoach_options_field').hasClass('healthcoach_options_no_use') && param.substr(0, 1)!='_' && !healthcoach_empty(field.val()) && field.val()!='none' && (field.attr('type') != 'checkbox' || field.get(0).checked)) {
			rez += ' '+param+'="'+healthcoach_shortcodes_prepare_value(field.val())+'"';
		}
		// On main tab detect param "custom"
		if (mainTab && param=='custom') {
			HEALTHCOACH_STORAGE['sc_custom'] = field.val();
		}
	});
	// Get additional params for general tab from items tabs
	if (HEALTHCOACH_STORAGE['sc_custom']!='no' && mainTab) {
		var sc = HEALTHCOACH_SHORTCODES_DATA[HEALTHCOACH_STORAGE['shortcodes_current_idx']];
		var sc_name = HEALTHCOACH_STORAGE['shortcodes_current_idx'];
		if (sc_name == 'trx_columns' || sc_name == 'trx_skills' || sc_name == 'trx_team' || sc_name == 'trx_price_table') {	// Determine "count" parameter
			var cnt = 0;
			tab.siblings('div').each(function() {
				var item_tab = jQuery(this);
				var merge = parseInt(item_tab.find('[data-param="span"]').val());
				cnt += !isNaN(merge) && merge > 0 ? merge : 1;
			});
			rez += ' count="'+cnt+'"';
		}
	}
	return rez;
}


// Shortcode parameters builder
//-------------------------------------------------------------------------------------------

// Prepare layout from shortcode object (array)
function healthcoach_shortcodes_prepare_layout(field) {
	"use strict";
	// Make params cloneable
	field['params'] = [field['params']];
	if (!healthcoach_empty(field.children)) {
		field.children['params'] = [field.children['params']];
	}
	// Prepare output
	var output = '<div class="healthcoach_shortcodes_body healthcoach_options_body"><form>';
	output += healthcoach_shortcodes_show_tabs(field);
	output += healthcoach_shortcodes_show_field(field, 0);
	if (!healthcoach_empty(field.children)) {
		HEALTHCOACH_STORAGE['shortcodes_tab_clone_content'] = healthcoach_shortcodes_show_field(field.children, 1);
		output += HEALTHCOACH_STORAGE['shortcodes_tab_clone_content'];
	}
	output += '</div></form></div>';
	return output;
}



// Show tabs
function healthcoach_shortcodes_show_tabs(field) {
	"use strict";
	// html output
	var output = '<div class="healthcoach_shortcodes_tab healthcoach_options_container healthcoach_options_tab">'
		+ '<ul>'
		+ HEALTHCOACH_STORAGE['shortcodes_tab_clone_tab'].replace(/{id}/g, 0).replace('{icon}', 'cog').replace('{title}', 'General');
	if (healthcoach_isset(field.children)) {
		for (var i=0; i<field.children.params.length; i++)
			output += HEALTHCOACH_STORAGE['shortcodes_tab_clone_tab'].replace(/{id}/g, i+1).replace('{icon}', 'cancel').replace('{title}', field.children.title + ' ' + (i+1));
		output += HEALTHCOACH_STORAGE['shortcodes_tab_clone_tab'].replace(/{id}/g, 'add').replace('{icon}', 'list-add').replace('{title}', '');
	}
	output += '</ul>';
	return output;
}

// Add new tab
function healthcoach_shortcodes_add_tab(tab) {
	"use strict";
	var idx = 0;
	tab.siblings().each(function () {
		"use strict";
		var i = parseInt(jQuery(this).data('id'));
		if (i > idx) idx = i;
	});
	idx++;
	tab.before( HEALTHCOACH_STORAGE['shortcodes_tab_clone_tab'].replace(/{id}/g, idx).replace('{icon}', 'cancel').replace('{title}', HEALTHCOACH_SHORTCODES_DATA[HEALTHCOACH_STORAGE['shortcodes_current_idx']].children.title + ' ' + idx) );
	tab.parents('.healthcoach_shortcodes_tab').append(HEALTHCOACH_STORAGE['shortcodes_tab_clone_content'].replace(/tab_1_/g, 'tab_' + idx + '_'));
	tab.parents('.healthcoach_shortcodes_tab').tabs('refresh');
	healthcoach_options_init(tab.parents('.healthcoach_shortcodes_tab').find('.healthcoach_options_tab_content').eq(idx));
	tab.prev().find('a').trigger('click');
}



// Show one field layout
function healthcoach_shortcodes_show_field(field, tab_idx) {
	"use strict";
	
	// html output
	var output = '';

	// Parse field params
	for (var clone_num in field['params']) {
		var tab_id = 'tab_' + (parseInt(tab_idx) + parseInt(clone_num));
		output += '<div id="healthcoach_shortcodes_' + tab_id + '_content" class="healthcoach_options_content healthcoach_options_tab_content">';

		for (var param_num in field['params'][clone_num]) {
			
			var param = field['params'][clone_num][param_num];
			var id = tab_id + '_' + param_num;
	
			// Divider after field
			var divider = healthcoach_isset(param['divider']) && param['divider'] ? ' healthcoach_options_divider' : '';
		
			// Setup default parameters
			if (param['type']=='media') {
				if (!healthcoach_isset(param['before'])) param['before'] = {};
				param['before'] = healthcoach_merge_objects({
						'title': 'Choose image',
						'action': 'media_upload',
						'type': 'image',
						'multiple': false,
						'sizes': false,
						'linked_field': '',
						'captions': { 	
							'choose': 'Choose image',
							'update': 'Select image'
							}
					}, param['before']);
				if (!healthcoach_isset(param['after'])) param['after'] = {};
				param['after'] = healthcoach_merge_objects({
						'icon': 'iconadmin-cancel',
						'action': 'media_reset'
					}, param['after']);
			}
			if (param['type']=='color' && (HEALTHCOACH_STORAGE['shortcodes_cp']=='tiny' || (healthcoach_isset(param['style']) && param['style']!='wp'))) {
				if (!healthcoach_isset(param['after'])) param['after'] = {};
				param['after'] = healthcoach_merge_objects({
						'icon': 'iconadmin-cancel',
						'action': 'color_reset'
					}, param['after']);
			}
		
			// Buttons before and after field
			var before = '', after = '', buttons_classes = '', rez, rez2, i, key, opt;
			
			if (healthcoach_isset(param['before'])) {
				rez = healthcoach_shortcodes_action_button(param['before'], 'before');
				before = rez[0];
				buttons_classes += rez[1];
			}
			if (healthcoach_isset(param['after'])) {
				rez = healthcoach_shortcodes_action_button(param['after'], 'after');
				after = rez[0];
				buttons_classes += rez[1];
			}
			if (healthcoach_in_array(param['type'], ['list', 'select', 'fonts']) || (param['type']=='socials' && (healthcoach_empty(param['style']) || param['style']=='icons'))) {
				buttons_classes += ' healthcoach_options_button_after_small';
			}

			if (param['type'] != 'hidden') {
				output += '<div class="healthcoach_options_field'
					+ ' healthcoach_options_field_' + (healthcoach_in_array(param['type'], ['list','fonts']) ? 'select' : param['type'])
					+ (healthcoach_in_array(param['type'], ['media', 'fonts', 'list', 'select', 'socials', 'date', 'time']) ? ' healthcoach_options_field_text'  : '')
					+ (param['type']=='socials' && !healthcoach_empty(param['style']) && param['style']=='images' ? ' healthcoach_options_field_images'  : '')
					+ (param['type']=='socials' && (healthcoach_empty(param['style']) || param['style']=='icons') ? ' healthcoach_options_field_icons'  : '')
					+ (healthcoach_isset(param['dir']) && param['dir']=='vertical' ? ' healthcoach_options_vertical' : '')
					+ (!healthcoach_empty(param['multiple']) ? ' healthcoach_options_multiple' : '')
					+ (healthcoach_isset(param['size']) ? ' healthcoach_options_size_'+param['size'] : '')
					+ (healthcoach_isset(param['class']) ? ' ' + param['class'] : '')
					+ divider 
					+ '">' 
					+ "\n"
					+ '<label class="healthcoach_options_field_label" for="' + id + '">' + param['title']
					+ '</label>'
					+ "\n"
					+ '<div class="healthcoach_options_field_content'
					+ buttons_classes
					+ '">'
					+ "\n";
			}
			
			if (!healthcoach_isset(param['value'])) {
				param['value'] = '';
			}
			

			switch ( param['type'] ) {
	
			case 'hidden':
				output += '<input class="healthcoach_options_input healthcoach_options_input_hidden" name="' + id + '" id="' + id + '" type="hidden" value="' + healthcoach_shortcodes_prepare_value(param['value']) + '" data-param="' + healthcoach_shortcodes_prepare_value(param_num) + '" />';
			break;

			case 'date':
				if (healthcoach_isset(param['style']) && param['style']=='inline') {
					output += '<div class="healthcoach_options_input_date"'
						+ ' id="' + id + '_calendar"'
						+ ' data-format="' + (!healthcoach_empty(param['format']) ? param['format'] : 'yy-mm-dd') + '"'
						+ ' data-months="' + (!healthcoach_empty(param['months']) ? max(1, min(3, param['months'])) : 1) + '"'
						+ ' data-linked-field="' + (!healthcoach_empty(data['linked_field']) ? data['linked_field'] : id) + '"'
						+ '></div>'
						+ '<input id="' + id + '"'
							+ ' name="' + id + '"'
							+ ' type="hidden"'
							+ ' value="' + healthcoach_shortcodes_prepare_value(param['value']) + '"'
							+ ' data-param="' + healthcoach_shortcodes_prepare_value(param_num) + '"'
							+ (!healthcoach_empty(param['action']) ? ' onchange="healthcoach_options_action_'+param['action']+'(this);return false;"' : '')
							+ ' />';
				} else {
					output += '<input class="healthcoach_options_input healthcoach_options_input_date' + (!healthcoach_empty(param['mask']) ? ' healthcoach_options_input_masked' : '') + '"'
						+ ' name="' + id + '"'
						+ ' id="' + id + '"'
						+ ' type="text"'
						+ ' value="' + healthcoach_shortcodes_prepare_value(param['value']) + '"'
						+ ' data-format="' + (!healthcoach_empty(param['format']) ? param['format'] : 'yy-mm-dd') + '"'
						+ ' data-months="' + (!healthcoach_empty(param['months']) ? max(1, min(3, param['months'])) : 1) + '"'
						+ ' data-param="' + healthcoach_shortcodes_prepare_value(param_num) + '"'
						+ (!healthcoach_empty(param['action']) ? ' onchange="healthcoach_options_action_'+param['action']+'(this);return false;"' : '')
						+ ' />'
						+ before 
						+ after;
				}
			break;

			case 'text':
				output += '<input class="healthcoach_options_input healthcoach_options_input_text' + (!healthcoach_empty(param['mask']) ? ' healthcoach_options_input_masked' : '') + '"'
					+ ' name="' + id + '"'
					+ ' id="' + id + '"'
					+ ' type="text"'
					+ ' value="' + healthcoach_shortcodes_prepare_value(param['value']) + '"'
					+ (!healthcoach_empty(param['mask']) ? ' data-mask="'+param['mask']+'"' : '') 
					+ ' data-param="' + healthcoach_shortcodes_prepare_value(param_num) + '"'
					+ (!healthcoach_empty(param['action']) ? ' onchange="healthcoach_options_action_'+param['action']+'(this);return false;"' : '')
					+ ' />'
				+ before 
				+ after;
			break;
		
			case 'textarea':
				var cols = healthcoach_isset(param['cols']) && param['cols'] > 10 ? param['cols'] : '40';
				var rows = healthcoach_isset(param['rows']) && param['rows'] > 1 ? param['rows'] : '8';
				output += '<textarea class="healthcoach_options_input healthcoach_options_input_textarea"'
					+ ' name="' + id + '"'
					+ ' id="' + id + '"'
					+ ' cols="' + cols + '"'
					+ ' rows="' + rows + '"'
					+ ' data-param="' + healthcoach_shortcodes_prepare_value(param_num) + '"'
					+ (!healthcoach_empty(param['action']) ? ' onchange="healthcoach_options_action_'+param['action']+'(this);return false;"' : '')
					+ '>'
					+ param['value']
					+ '</textarea>';
			break;

			case 'spinner':
				output += '<input class="healthcoach_options_input healthcoach_options_input_spinner' + (!healthcoach_empty(param['mask']) ? ' healthcoach_options_input_masked' : '') + '"'
					+ ' name="' + id + '"'
					+ ' id="' + id + '"'
					+ ' type="text"'
					+ ' value="' + healthcoach_shortcodes_prepare_value(param['value']) + '"' 
					+ (!healthcoach_empty(param['mask']) ? ' data-mask="'+param['mask']+'"' : '') 
					+ (healthcoach_isset(param['min']) ? ' data-min="'+param['min']+'"' : '') 
					+ (healthcoach_isset(param['max']) ? ' data-max="'+param['max']+'"' : '') 
					+ (!healthcoach_empty(param['step']) ? ' data-step="'+param['step']+'"' : '') 
					+ ' data-param="' + healthcoach_shortcodes_prepare_value(param_num) + '"'
					+ (!healthcoach_empty(param['action']) ? ' onchange="healthcoach_options_action_'+param['action']+'(this);return false;"' : '')
					+ ' />' 
					+ '<span class="healthcoach_options_arrows"><span class="healthcoach_options_arrow_up iconadmin-up-dir"></span><span class="healthcoach_options_arrow_down iconadmin-down-dir"></span></span>';
			break;

			case 'tags':
				var tags = param['value'].split(HEALTHCOACH_STORAGE['shortcodes_delimiter']);
				if (tags.length > 0) {
					for (i=0; i<tags.length; i++) {
						if (healthcoach_empty(tags[i])) continue;
						output += '<span class="healthcoach_options_tag iconadmin-cancel">' + tags[i] + '</span>';
					}
				}
				output += '<input class="healthcoach_options_input_tags"'
					+ ' type="text"'
					+ ' value=""'
					+ ' />'
					+ '<input name="' + id + '"'
						+ ' type="hidden"'
						+ ' value="' + healthcoach_shortcodes_prepare_value(param['value']) + '"'
						+ ' data-param="' + healthcoach_shortcodes_prepare_value(param_num) + '"'
						+ (!healthcoach_empty(param['action']) ? ' onchange="healthcoach_options_action_'+param['action']+'(this);return false;"' : '')
						+ ' />';
			break;
		
			case "checkbox": 
				output += '<input type="checkbox" class="healthcoach_options_input healthcoach_options_input_checkbox"'
					+ ' name="' + id + '"'
					+ ' id="' + id + '"'
					+ ' value="true"' 
					+ (param['value'] == 'true' ? ' checked="checked"' : '') 
					+ (!healthcoach_empty(param['disabled']) ? ' readonly="readonly"' : '') 
					+ ' data-param="' + healthcoach_shortcodes_prepare_value(param_num) + '"'
					+ (!healthcoach_empty(param['action']) ? ' onchange="healthcoach_options_action_'+param['action']+'(this);return false;"' : '')
					+ ' />'
					+ '<label for="' + id + '" class="' + (!healthcoach_empty(param['disabled']) ? 'healthcoach_options_state_disabled' : '') + (param['value']=='true' ? ' healthcoach_options_state_checked' : '') + '"><span class="healthcoach_options_input_checkbox_image iconadmin-check"></span>' + (!healthcoach_empty(param['label']) ? param['label'] : param['title']) + '</label>';
			break;
		
			case "radio":
				for (key in param['options']) { 
					output += '<span class="healthcoach_options_radioitem"><input class="healthcoach_options_input healthcoach_options_input_radio" type="radio"'
						+ ' name="' + id + '"'
						+ ' value="' + healthcoach_shortcodes_prepare_value(key) + '"'
						+ ' data-value="' + healthcoach_shortcodes_prepare_value(key) + '"'
						+ (param['value'] == key ? ' checked="checked"' : '') 
						+ ' id="' + id + '_' + key + '"'
						+ ' />'
						+ '<label for="' + id + '_' + key + '"' + (param['value'] == key ? ' class="healthcoach_options_state_checked"' : '') + '><span class="healthcoach_options_input_radio_image iconadmin-circle-empty' + (param['value'] == key ? ' iconadmin-dot-circled' : '') + '"></span>' + param['options'][key] + '</label></span>';
				}
				output += '<input type="hidden"'
						+ ' value="' + healthcoach_shortcodes_prepare_value(param['value']) + '"'
						+ ' data-param="' + healthcoach_shortcodes_prepare_value(param_num) + '"'
						+ (!healthcoach_empty(param['action']) ? ' onchange="healthcoach_options_action_'+param['action']+'(this);return false;"' : '')
						+ ' />';

			break;
		
			case "switch":
				opt = [];
				i = 0;
				for (key in param['options']) {
					opt[i++] = {'key': key, 'title': param['options'][key]};
					if (i==2) break;
				}
				output += '<input name="' + id + '"'
					+ ' type="hidden"'
					+ ' value="' + healthcoach_shortcodes_prepare_value(healthcoach_empty(param['value']) ? opt[0]['key'] : param['value']) + '"'
					+ ' data-param="' + healthcoach_shortcodes_prepare_value(param_num) + '"'
					+ (!healthcoach_empty(param['action']) ? ' onchange="healthcoach_options_action_'+param['action']+'(this);return false;"' : '')
					+ ' />'
					+ '<span class="healthcoach_options_switch' + (param['value']==opt[1]['key'] ? ' healthcoach_options_state_off' : '') + '"><span class="healthcoach_options_switch_inner iconadmin-circle"><span class="healthcoach_options_switch_val1" data-value="' + opt[0]['key'] + '">' + opt[0]['title'] + '</span><span class="healthcoach_options_switch_val2" data-value="' + opt[1]['key'] + '">' + opt[1]['title'] + '</span></span></span>';
			break;

			case 'media':
				output += '<input class="healthcoach_options_input healthcoach_options_input_text healthcoach_options_input_media"'
					+ ' name="' + id + '"'
					+ ' id="' + id + '"'
					+ ' type="text"'
					+ ' value="' + healthcoach_shortcodes_prepare_value(param['value']) + '"'
					+ (!healthcoach_isset(param['readonly']) || param['readonly'] ? ' readonly="readonly"' : '')
					+ ' data-param="' + healthcoach_shortcodes_prepare_value(param_num) + '"'
					+ (!healthcoach_empty(param['action']) ? ' onchange="healthcoach_options_action_'+param['action']+'(this);return false;"' : '')
					+ ' />'
					+ before 
					+ after;
				if (!healthcoach_empty(param['value'])) {
					var fname = healthcoach_get_file_name(param['value']);
					var fext  = healthcoach_get_file_ext(param['value']);
					output += '<a class="healthcoach_options_image_preview" rel="prettyPhoto" target="_blank" href="' + param['value'] + '">' + (fext!='' && healthcoach_in_list('jpg,png,gif', fext, ',') ? '<img src="'+param['value']+'" alt="" />' : '<span>'+fname+'</span>') + '</a>';
				}
			break;
		
			case 'button':
				rez = healthcoach_shortcodes_action_button(param, 'button');
				output += rez[0];
			break;

			case 'range':
				output += '<div class="healthcoach_options_input_range" data-step="'+(!healthcoach_empty(param['step']) ? param['step'] : 1) + '">'
					+ '<span class="healthcoach_options_range_scale"><span class="healthcoach_options_range_scale_filled"></span></span>';
				if (param['value'].toString().indexOf(HEALTHCOACH_STORAGE['shortcodes_delimiter']) == -1)
					param['value'] = Math.min(param['max'], Math.max(param['min'], param['value']));
				var sliders = param['value'].toString().split(HEALTHCOACH_STORAGE['shortcodes_delimiter']);
				for (i=0; i<sliders.length; i++) {
					output += '<span class="healthcoach_options_range_slider"><span class="healthcoach_options_range_slider_value">' + sliders[i] + '</span><span class="healthcoach_options_range_slider_button"></span></span>';
				}
				output += '<span class="healthcoach_options_range_min">' + param['min'] + '</span><span class="healthcoach_options_range_max">' + param['max'] + '</span>'
					+ '<input name="' + id + '"'
						+ ' type="hidden"'
						+ ' value="' + healthcoach_shortcodes_prepare_value(param['value']) + '"'
						+ ' data-param="' + healthcoach_shortcodes_prepare_value(param_num) + '"'
						+ (!healthcoach_empty(param['action']) ? ' onchange="healthcoach_options_action_'+param['action']+'(this);return false;"' : '')
						+ ' />'
					+ '</div>';			
			break;
		
			case "checklist":
				for (key in param['options']) { 
					output += '<span class="healthcoach_options_listitem'
						+ (healthcoach_in_list(param['value'], key, HEALTHCOACH_STORAGE['shortcodes_delimiter']) ? ' healthcoach_options_state_checked' : '') + '"'
						+ ' data-value="' + healthcoach_shortcodes_prepare_value(key) + '"'
						+ '>'
						+ param['options'][key]
						+ '</span>';
				}
				output += '<input name="' + id + '"'
					+ ' type="hidden"'
					+ ' value="' + healthcoach_shortcodes_prepare_value(param['value']) + '"'
					+ ' data-param="' + healthcoach_shortcodes_prepare_value(param_num) + '"'
					+ (!healthcoach_empty(param['action']) ? ' onchange="healthcoach_options_action_'+param['action']+'(this);return false;"' : '')
					+ ' />';
			break;
		
			case 'fonts':
				for (key in param['options']) {
					param['options'][key] = key;
				}
			case 'list':
			case 'select':
				if (!healthcoach_isset(param['options']) && !healthcoach_empty(param['from']) && !healthcoach_empty(param['to'])) {
					param['options'] = [];
					for (i = param['from']; i <= param['to']; i+=(!healthcoach_empty(param['step']) ? param['step'] : 1)) {
						param['options'][i] = i;
					}
				}
				rez = healthcoach_shortcodes_menu_list(param);
				if (healthcoach_empty(param['style']) || param['style']=='select') {
					output += '<input class="healthcoach_options_input healthcoach_options_input_select" type="text" value="' + healthcoach_shortcodes_prepare_value(rez[1]) + '"'
						+ ' readonly="readonly"'
						+ ' />'
						+ '<span class="healthcoach_options_field_after healthcoach_options_with_action iconadmin-down-open" onchange="healthcoach_options_action_show_menu(this);return false;"></span>';
				}
				output += rez[0]
					+ '<input name="' + id + '"'
						+ ' type="hidden"'
						+ ' value="' + healthcoach_shortcodes_prepare_value(param['value']) + '"'
						+ ' data-param="' + healthcoach_shortcodes_prepare_value(param_num) + '"'
						+ (!healthcoach_empty(param['action']) ? ' onchange="healthcoach_options_action_'+param['action']+'(this);return false;"' : '')
						+ ' />';
			break;

			case 'images':
				rez = healthcoach_shortcodes_menu_list(param);
				if (healthcoach_empty(param['style']) || param['style']=='select') {
					output += '<div class="healthcoach_options_caption_image iconadmin-down-open">'
						+'<span style="background-image: url(' + rez[1] + ')"></span>'
						+'</div>';
				}
				output += rez[0]
					+ '<input name="' + id + '"'
						+ ' type="hidden"'
						+ ' value="' + healthcoach_shortcodes_prepare_value(param['value']) + '"'
						+ ' data-param="' + healthcoach_shortcodes_prepare_value(param_num) + '"'
						+ (!healthcoach_empty(param['action']) ? ' onchange="healthcoach_options_action_'+param['action']+'(this);return false;"' : '')
						+ ' />';
			break;
		
			case 'icons':
				rez = healthcoach_shortcodes_menu_list(param);
				if (healthcoach_empty(param['style']) || param['style']=='select') {
					output += '<div class="healthcoach_options_caption_icon iconadmin-down-open"><span class="' + rez[1] + '"></span></div>';
				}
				output += rez[0]
					+ '<input name="' + id + '"'
						+ ' type="hidden"'
						+ ' value="' + healthcoach_shortcodes_prepare_value(param['value']) + '"'
						+ ' data-param="' + healthcoach_shortcodes_prepare_value(param_num) + '"'
						+ (!healthcoach_empty(param['action']) ? ' onchange="healthcoach_options_action_'+param['action']+'(this);return false;"' : '')
						+ ' />';
			break;

			case 'socials':
				if (!healthcoach_is_object(param['value'])) param['value'] = {'url': '', 'icon': ''};
				rez = healthcoach_shortcodes_menu_list(param);
				if (healthcoach_empty(param['style']) || param['style']=='icons') {
					rez2 = healthcoach_shortcodes_action_button({
						'action': healthcoach_empty(param['style']) || param['style']=='icons' ? 'select_icon' : '',
						'icon': (healthcoach_empty(param['style']) || param['style']=='icons') && !healthcoach_empty(param['value']['icon']) ? param['value']['icon'] : 'iconadmin-users'
						}, 'after');
				} else
					rez2 = ['', ''];
				output += '<input class="healthcoach_options_input healthcoach_options_input_text healthcoach_options_input_socials' 
					+ (!healthcoach_empty(param['mask']) ? ' healthcoach_options_input_masked' : '') + '"'
					+ ' name="' + id + '"'
					+ ' id="' + id + '"'
					+ ' type="text" value="' + healthcoach_shortcodes_prepare_value(param['value']['url']) + '"' 
					+ (!healthcoach_empty(param['mask']) ? ' data-mask="'+param['mask']+'"' : '') 
					+ ' data-param="' + healthcoach_shortcodes_prepare_value(param_num) + '"'
					+ (!healthcoach_empty(param['action']) ? ' onchange="healthcoach_options_action_'+param['action']+'(this);return false;"' : '')
					+ ' />'
					+ rez2[0];
				if (!healthcoach_empty(param['style']) && param['style']=='images') {
					output += '<div class="healthcoach_options_caption_image iconadmin-down-open">'
						+'<span style="background-image: url(' + rez[1] + ')"></span>'
						+'</div>';
				}
				output += rez[0]
					+ '<input name="' + id + '_icon' + '" type="hidden" value="' + healthcoach_shortcodes_prepare_value(param['value']['icon']) + '" />';
			break;

			case "color":
				var cp_style = healthcoach_isset(param['style']) ? param['style'] : HEALTHCOACH_STORAGE['shortcodes_cp'];
				output += '<input class="healthcoach_options_input healthcoach_options_input_color healthcoach_options_input_color_'+cp_style +'"'
					+ ' name="' + id + '"'
					+ ' id="' + id + '"'
					+ ' data-param="' + healthcoach_shortcodes_prepare_value(param_num) + '"'
					+ ' type="text"'
					+ ' value="' + healthcoach_shortcodes_prepare_value(param['value']) + '"'
					+ (!healthcoach_empty(param['action']) ? ' onchange="healthcoach_options_action_'+param['action']+'(this);return false;"' : '')
					+ ' />'
					+ before;
				if (cp_style=='custom')
					output += '<span class="healthcoach_options_input_colorpicker iColorPicker"></span>';
				else if (cp_style=='tiny')
					output += after;
			break;   
	
			}

			if (param['type'] != 'hidden') {
				output += '</div>';
				if (!healthcoach_empty(param['desc']))
					output += '<div class="healthcoach_options_desc">' + param['desc'] + '</div>' + "\n";
				output += '</div>' + "\n";
			}

		}

		output += '</div>';
	}

	
	return output;
}



// Return menu items list (menu, images or icons)
function healthcoach_shortcodes_menu_list(field) {
	"use strict";
	if (field['type'] == 'socials') field['value'] = field['value']['icon'];
	var list = '<div class="healthcoach_options_input_menu ' + (healthcoach_empty(field['style']) ? '' : ' healthcoach_options_input_menu_' + field['style']) + '">';
	var caption = '';
	for (var key in field['options']) {
		var value = field['options'][key];
		if (healthcoach_in_array(field['type'], ['list', 'icons', 'socials'])) key = value;
		var selected = '';
		if (healthcoach_in_list(field['value'], key, HEALTHCOACH_STORAGE['shortcodes_delimiter'])) {
			caption = value;
			selected = ' healthcoach_options_state_checked';
		}
		list += '<span class="healthcoach_options_menuitem' 
			+ selected 
			+ '" data-value="' + healthcoach_shortcodes_prepare_value(key) + '"'
			+ '>';
		if (healthcoach_in_array(field['type'], ['list', 'select', 'fonts']))
			list += value;
		else if (field['type'] == 'icons' || (field['type'] == 'socials' && field['style'] == 'icons'))
			list += '<span class="' + value + '"></span>';
		else if (field['type'] == 'images' || (field['type'] == 'socials' && field['style'] == 'images'))
			list += '<span style="background-image:url(' + value + ')" data-src="' + value + '" data-icon="' + key + '" class="healthcoach_options_input_image"></span>';
		list += '</span>';
	}
	list += '</div>';
	return [list, caption];
}



// Return action button
function healthcoach_shortcodes_action_button(data, type) {
	"use strict";
	var class_name = ' healthcoach_options_button_' + type + (healthcoach_empty(data['title']) ? ' healthcoach_options_button_'+type+'_small' : '');
	var output = '<span class="' 
				+ (type == 'button' ? 'healthcoach_options_input_button'  : 'healthcoach_options_field_'+type)
				+ (!healthcoach_empty(data['action']) ? ' healthcoach_options_with_action' : '')
				+ (!healthcoach_empty(data['icon']) ? ' '+data['icon'] : '')
				+ '"'
				+ (!healthcoach_empty(data['icon']) && !healthcoach_empty(data['title']) ? ' title="'+healthcoach_shortcodes_prepare_value(data['title'])+'"' : '')
				+ (!healthcoach_empty(data['action']) ? ' onclick="healthcoach_options_action_'+data['action']+'(this);return false;"' : '')
				+ (!healthcoach_empty(data['type']) ? ' data-type="'+data['type']+'"' : '')
				+ (!healthcoach_empty(data['multiple']) ? ' data-multiple="'+data['multiple']+'"' : '')
				+ (!healthcoach_empty(data['sizes']) ? ' data-sizes="'+data['sizes']+'"' : '')
				+ (!healthcoach_empty(data['linked_field']) ? ' data-linked-field="'+data['linked_field']+'"' : '')
				+ (!healthcoach_empty(data['captions']) && !healthcoach_empty(data['captions']['choose']) ? ' data-caption-choose="'+healthcoach_shortcodes_prepare_value(data['captions']['choose'])+'"' : '')
				+ (!healthcoach_empty(data['captions']) && !healthcoach_empty(data['captions']['update']) ? ' data-caption-update="'+healthcoach_shortcodes_prepare_value(data['captions']['update'])+'"' : '')
				+ '>'
				+ (type == 'button' || (healthcoach_empty(data['icon']) && !healthcoach_empty(data['title'])) ? data['title'] : '')
				+ '</span>';
	return [output, class_name];
}

// Prepare string to insert as parameter's value
function healthcoach_shortcodes_prepare_value(val) {
	return typeof val == 'string' ? val.replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/'/g, '&#039;').replace(/</g, '&lt;').replace(/>/g, '&gt;') : val;
}
