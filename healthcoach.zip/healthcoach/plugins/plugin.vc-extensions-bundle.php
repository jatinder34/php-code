<?php
/* Visual Composer support functions
------------------------------------------------------------------------------- */

// Theme init
if (!function_exists('healthcoach_vc_extensions_bundle_theme_setup')) {
	add_action( 'healthcoach_action_before_init_theme', 'healthcoach_vc_extensions_bundle_theme_setup', 1 );
	function healthcoach_vc_extensions_bundle_theme_setup() {
		if (is_admin()) {
			add_filter( 'healthcoach_filter_importer_required_plugins',		'healthcoach_vc_extensions_bundle_importer_required_plugins', 10, 2 );
			add_filter( 'healthcoach_filter_required_plugins',					'healthcoach_vc_extensions_bundle_required_plugins' );
		}
	}
}

// Check if Visual Composer installed and activated
if ( !function_exists( 'healthcoach_exists_vc_extensions_bundle' ) ) {
	function healthcoach_exists_vc_extensions_bundle() {
		return class_exists('VC_Extensions_CQBundle');
	}
}

// Filter to add in the required plugins list
if ( !function_exists( 'healthcoach_vc_extensions_bundle_required_plugins' ) ) {
	//add_filter('healthcoach_filter_required_plugins',	'healthcoach_vc_extensions_bundle_required_plugins');
	function healthcoach_vc_extensions_bundle_required_plugins($list=array()) {
		if (in_array('vc_extensions_bundle', healthcoach_storage_get('required_plugins'))) {
			$path = healthcoach_get_file_dir('plugins/install/vc-extensions-bundle.pak');
			if (file_exists($path)) {
				$list[] = array(
					'name' 		=> 'Visual Composer Extensions All In One',
					'slug' 		=> 'vc-extensions-bundle',
					'source'	=> $path,
					'required' 	=> false
				);
			}
		}
		return $list;
	}
}



// One-click import support
//------------------------------------------------------------------------

// Check VC in the required plugins
if ( !function_exists( 'healthcoach_vc_extensions_bundle_importer_required_plugins' ) ) {
	//add_filter( 'healthcoach_filter_importer_required_plugins',	'healthcoach_vc_extensions_bundle_importer_required_plugins', 10, 2 );
	function healthcoach_vc_extensions_bundle_importer_required_plugins($not_installed='', $list='') {
		//if (in_array('visual_composer', healthcoach_storage_get('required_plugins')) && !healthcoach_exists_vc_extensions_bundle() && healthcoach_get_value_gp('data_type')=='vc' )
		if (!healthcoach_exists_vc_extensions_bundle() )		// && healthcoach_strpos($list, 'visual_composer')!==false
			$not_installed .= '<br>Visual Composer Extensions All In One';
		return $not_installed;
	}
}
?>