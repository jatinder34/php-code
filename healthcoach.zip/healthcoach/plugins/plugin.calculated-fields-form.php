<?php
/* Calculated fields form support functions
------------------------------------------------------------------------------- */

// Theme init
if (!function_exists('healthcoach_calcfields_form_theme_setup')) {
	add_action( 'healthcoach_action_before_init_theme', 'healthcoach_calcfields_form_theme_setup', 1 );
	function healthcoach_calcfields_form_theme_setup() {
		// Register shortcode in the shortcodes list
		if (healthcoach_exists_calcfields_form()) {
			add_action('healthcoach_action_shortcodes_list',				'healthcoach_calcfields_form_reg_shortcodes');
			if (function_exists('healthcoach_exists_visual_composer') && healthcoach_exists_visual_composer())
				add_action('healthcoach_action_shortcodes_list_vc',		'healthcoach_calcfields_form_reg_shortcodes_vc');
			if (is_admin()) {
				add_filter( 'healthcoach_filter_importer_options',			'healthcoach_calcfields_form_importer_set_options', 10, 1 );
				add_action( 'healthcoach_action_importer_params',			'healthcoach_calcfields_form_importer_show_params', 10, 1 );
				add_action( 'healthcoach_action_importer_import',			'healthcoach_calcfields_form_importer_import', 10, 2 );
				add_action( 'healthcoach_action_importer_import_fields',	'healthcoach_calcfields_form_importer_import_fields', 10, 1 );
				add_action( 'healthcoach_action_importer_export',			'healthcoach_calcfields_form_importer_export', 10, 1 );
				add_action( 'healthcoach_action_importer_export_fields',	'healthcoach_calcfields_form_importer_export_fields', 10, 1 );
			}
		}
		if (is_admin()) {
			add_filter( 'healthcoach_filter_importer_required_plugins',	'healthcoach_calcfields_form_importer_required_plugins', 10, 2 );
			add_filter( 'healthcoach_filter_required_plugins',				'healthcoach_calcfields_form_required_plugins' );
		}
	}
}

// Check if plugin installed and activated
if ( !function_exists( 'healthcoach_exists_calcfields_form' ) ) {
	function healthcoach_exists_calcfields_form() {
		return defined('CP_SCHEME');
	}
}

// Filter to add in the required plugins list
if ( !function_exists( 'healthcoach_calcfields_form_required_plugins' ) ) {
	//add_filter('healthcoach_filter_required_plugins',	'healthcoach_calcfields_form_required_plugins');
	function healthcoach_calcfields_form_required_plugins($list=array()) {
		if (in_array('calcfields', healthcoach_storage_get('required_plugins')))
			$list[] = array(
					'name' 		=> esc_html__('Calculated Fields Form', 'healthcoach'),
					'slug' 		=> 'calculated-fields-form',
					'required' 	=> false
					);
		return $list;
	}
}

// Remove jquery_ui from frontend
if ( !function_exists( 'healthcoach_calcfields_form_frontend_scripts' ) ) {
	//add_action('wp_enqueue_scripts', 'healthcoach_calcfields_form_frontend_scripts');
	function healthcoach_calcfields_form_frontend_scripts() {
		global $wp_styles;
		$wp_styles->done[] = 'cpcff_jquery_ui';
	}
}


// One-click import support
//------------------------------------------------------------------------

// Check in the required plugins
if ( !function_exists( 'healthcoach_calcfields_form_importer_required_plugins' ) ) {
	//add_filter( 'healthcoach_filter_importer_required_plugins',	'healthcoach_calcfields_form_importer_required_plugins', 10, 2 );
	function healthcoach_calcfields_form_importer_required_plugins($not_installed='', $list='') {
		if (healthcoach_strpos($list, 'calcfields')!==false && !healthcoach_exists_calcfields_form() )
			$not_installed .= '<br>'.esc_html__('Calculated Fields Form', 'healthcoach');
		return $not_installed;
	}
}

// Set options for one-click importer
if ( !function_exists( 'healthcoach_calcfields_form_importer_set_options' ) ) {
	//add_filter( 'healthcoach_filter_importer_options',	'healthcoach_calcfields_form_importer_set_options', 10, 1 );
	function healthcoach_calcfields_form_importer_set_options($options=array()) {
		if ( in_array('calcfields', healthcoach_storage_get('required_plugins')) && healthcoach_exists_calcfields_form() ) {
			$options['additional_options'][]	= 'CP_CFF_LOAD_SCRIPTS';				// Add slugs to export options of this plugin
			$options['additional_options'][]	= 'CP_CALCULATEDFIELDSF_USE_CACHE';
			$options['additional_options'][]	= 'CP_CALCULATEDFIELDSF_EXCLUDE_CRAWLERS';
			if (is_array($options['files']) && count($options['files']) > 0) {
				foreach ($options['files'] as $k => $v) {
					$options['files'][$k]['file_with_calcfields_form'] = str_replace('name.ext', 'calcfields_form.txt', $v['file_with_']);
				}
			}
		}
		return $options;
	}
}

// Add checkbox to the one-click importer
if ( !function_exists( 'healthcoach_calcfields_form_importer_show_params' ) ) {
	//add_action( 'healthcoach_action_importer_params',	'healthcoach_calcfields_form_importer_show_params', 10, 1 );
	function healthcoach_calcfields_form_importer_show_params($importer) {
		$importer->show_importer_params(array(
			'slug' => 'calcfields_form',
			'title' => esc_html__('Import Calculated Fields Form', 'healthcoach'),
			'part' => 1
			));
	}
}

// Import posts
if ( !function_exists( 'healthcoach_calcfields_form_importer_import' ) ) {
	//add_action( 'healthcoach_action_importer_import',	'healthcoach_calcfields_form_importer_import', 10, 2 );
	function healthcoach_calcfields_form_importer_import($importer, $action) {
		if ( $action == 'import_calcfields_form' ) {
			$importer->response['start_from_id'] = 0;
			$importer->import_dump('calcfields_form', esc_html__('Calculated Fields Form', 'healthcoach'));
		}
	}
}

// Display import progress
if ( !function_exists( 'healthcoach_calcfields_form_importer_import_fields' ) ) {
	//add_action( 'healthcoach_action_importer_import_fields',	'healthcoach_calcfields_form_importer_import_fields', 10, 1 );
	function healthcoach_calcfields_form_importer_import_fields($importer) {
		$importer->show_importer_fields(array(
			'slug' => 'calcfields_form',
			'title' => esc_html__('Calculated Fields Form', 'healthcoach')
			));
	}
}

// Export posts
if ( !function_exists( 'healthcoach_calcfields_form_importer_export' ) ) {
	//add_action( 'healthcoach_action_importer_export',	'healthcoach_calcfields_form_importer_export', 10, 1 );
	function healthcoach_calcfields_form_importer_export($importer) {
		healthcoach_fpc(healthcoach_get_file_dir('core/core.importer/export/calcfields_form.txt'), serialize( array(
			CP_CALCULATEDFIELDSF_FORMS_TABLE => $importer->export_dump(CP_CALCULATEDFIELDSF_FORMS_TABLE)
			) )
		);
	}
}

// Display exported data in the fields
if ( !function_exists( 'healthcoach_calcfields_form_importer_export_fields' ) ) {
	//add_action( 'healthcoach_action_importer_export_fields',	'healthcoach_calcfields_form_importer_export_fields', 10, 1 );
	function healthcoach_calcfields_form_importer_export_fields($importer) {
		$importer->show_exporter_fields(array(
			'slug' => 'calcfields_form',
			'title' => esc_html__('Calculated Fields Form', 'healthcoach')
			));
	}
}


// Lists
//------------------------------------------------------------------------

// Return Calculated forms list list, prepended inherit (if need)
if ( !function_exists( 'healthcoach_get_list_calcfields_form' ) ) {
	function healthcoach_get_list_calcfields_form($prepend_inherit=false) {
		if (($list = healthcoach_storage_get('list_calcfields_form'))=='') {
			$list = array();
			if (healthcoach_exists_calcfields_form()) {
				global $wpdb;
				$rows = $wpdb->get_results( "SELECT id, form_name FROM " . esc_sql($wpdb->prefix . CP_CALCULATEDFIELDSF_FORMS_TABLE) );
				if (is_array($rows) && count($rows) > 0) {
					foreach ($rows as $row) {
						$list[$row->id] = $row->form_name;
					}
				}
			}
			$list = apply_filters('healthcoach_filter_list_calcfields_form', $list);
			if (healthcoach_get_theme_setting('use_list_cache')) healthcoach_storage_set('list_calcfields_form', $list); 
		}
		return $prepend_inherit ? healthcoach_array_merge(array('inherit' => esc_html__("Inherit", 'healthcoach')), $list) : $list;
	}
}



// Shortcodes
//------------------------------------------------------------------------

// Register shortcode in the shortcodes list
if (!function_exists('healthcoach_calcfields_form_reg_shortcodes')) {
	//add_filter('healthcoach_action_shortcodes_list',	'healthcoach_calcfields_form_reg_shortcodes');
	function healthcoach_calcfields_form_reg_shortcodes() {
		if (healthcoach_storage_isset('shortcodes')) {

			$forms_list = healthcoach_get_list_calcfields_form();

			healthcoach_sc_map_after( 'trx_button', 'CP_CALCULATED_FIELDS', array(
					"title" => esc_html__("Calculated fields form", 'healthcoach'),
					"desc" => esc_html__("Insert calculated fields form", 'healthcoach'),
					"decorate" => true,
					"container" => false,
					"params" => array(
						"id" => array(
							"title" => esc_html__("Form ID", 'healthcoach'),
							"desc" => esc_html__("Select Form to insert into current page", 'healthcoach'),
							"value" => "",
							"size" => "medium",
							"options" => $forms_list,
							"type" => "select"
							)
						)
					)
			);
		}
	}
}


// Register shortcode in the VC shortcodes list
if (!function_exists('healthcoach_calcfields_form_reg_shortcodes_vc')) {
	//add_filter('healthcoach_action_shortcodes_list_vc',	'healthcoach_calcfields_form_reg_shortcodes_vc');
	function healthcoach_calcfields_form_reg_shortcodes_vc() {

		$forms_list = healthcoach_get_list_calcfields_form();

		// Calculated fields form
		vc_map( array(
				"base" => "CP_CALCULATED_FIELDS",
				"name" => esc_html__("Calculated fields form", 'healthcoach'),
				"description" => esc_html__("Insert calculated fields form", 'healthcoach'),
				"category" => esc_html__('Content', 'healthcoach'),
				'icon' => 'icon_trx_calcfields',
				"class" => "trx_sc_single trx_sc_calcfields",
				"content_element" => true,
				"is_container" => false,
				"show_settings_on_create" => true,
				"params" => array(
					array(
						"param_name" => "id",
						"heading" => esc_html__("Form ID", 'healthcoach'),
						"description" => esc_html__("Select Form to insert into current page", 'healthcoach'),
						"admin_label" => true,
						"class" => "",
						"value" => array_flip($forms_list),
						"type" => "dropdown"
					)
				)
			) );
			
		class WPBakeryShortCode_Cp_Calculated_Fields extends HEALTHCOACH_VC_ShortCodeSingle {}

	}
}
?>