<?php
/**
 * Single post
 */
get_header(); 

$single_style = healthcoach_storage_get('single_style');
if (empty($single_style)) $single_style = healthcoach_get_custom_option('single_style');

while ( have_posts() ) { the_post();
	healthcoach_show_post_layout(
		array(
			'layout' => $single_style,
			'sidebar' => !healthcoach_param_is_off(healthcoach_get_custom_option('show_sidebar_main')),
			'content' => healthcoach_get_template_property($single_style, 'need_content'),
			'terms_list' => healthcoach_get_template_property($single_style, 'need_terms')
		)
	);
}

get_footer();
?>