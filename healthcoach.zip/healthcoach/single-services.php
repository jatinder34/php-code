<?php
/*
 * Service item
 */
get_template_part('single');
?>