<?php
/*
 * Team member
 */
healthcoach_storage_set('single_style', 'single-team');

get_template_part('single');
?>