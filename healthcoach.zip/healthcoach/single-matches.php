<?php
/*
 * Matches item
 */
healthcoach_storage_set('single_style', 'single-matches');

get_template_part('single');
?>