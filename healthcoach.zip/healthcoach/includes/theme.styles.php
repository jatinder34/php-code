<?php
/**
 * Theme custom styles
 */

// Disable direct call
if ( ! defined( 'ABSPATH' ) ) { exit; }


/* Theme setup section
-------------------------------------------------------------------- */

if (!function_exists('healthcoach_action_theme_styles_theme_setup')) {
	add_action( 'healthcoach_action_before_init_theme', 'healthcoach_action_theme_styles_theme_setup', 1 );
	function healthcoach_action_theme_styles_theme_setup() {
	
		// Add theme fonts in the used fonts list
		add_filter('healthcoach_filter_used_fonts',			'healthcoach_filter_theme_styles_used_fonts');
		// Add theme fonts (from Google fonts) in the main fonts list (if not present).
		add_filter('healthcoach_filter_list_fonts',			'healthcoach_filter_theme_styles_list_fonts');

		// Add theme stylesheets
		add_action('healthcoach_action_add_styles',			'healthcoach_action_theme_styles_add_styles');
		// Add theme inline styles
		add_filter('healthcoach_filter_add_styles_inline',		'healthcoach_filter_theme_styles_add_styles_inline');

		// Add theme scripts
		add_action('healthcoach_action_add_scripts',			'healthcoach_action_theme_styles_add_scripts');
		// Add theme scripts inline
		add_filter('healthcoach_filter_localize_script',		'healthcoach_filter_theme_styles_localize_script');

		// Add theme less files into list for compilation
		add_filter('healthcoach_filter_compile_less',			'healthcoach_filter_theme_styles_compile_less');


		// Add color schemes
		healthcoach_add_color_scheme('original', array(

			'title'					=> esc_html__('Original', 'healthcoach'),
			
			// Whole block border and background
			'bd_color'				=> '#e4e7e8',
			'bg_color'				=> '#ffffff',
			
			// Headers, text and links colors
			'text'					=> '#666666',
			'text_light'			=> '#888888',
			'text_dark'				=> '#454545',
			'text_link'				=> '#5ebf55',
			'text_hover'			=> '#4ba143',

			// Inverse colors
			'inverse_text'			=> '#ffffff',
			'inverse_light'			=> '#ffffff',
			'inverse_dark'			=> '#ffffff',
			'inverse_link'			=> '#ffffff',
			'inverse_hover'			=> '#ffffff',
		
			// Input fields
			'input_text'			=> '#8a8a8a',
			'input_light'			=> '#888888',
			'input_dark'			=> '#232a34',
			'input_bd_color'		=> '#dddddd',
			'input_bd_hover'		=> '#bbbbbb',
			'input_bg_color'		=> '#f7f7f7',
			'input_bg_hover'		=> '#f0f0f0',
		
			// Alternative blocks (submenu items, etc.)
			'alter_text'			=> '#8a8a8a',
			'alter_light'			=> '#acb4b6',
			'alter_dark'			=> '#232a34',
			'alter_link'			=> '#e55a57',
			'alter_hover'			=> '#189799',
			'alter_bd_color'		=> '#dddddd',
			'alter_bd_hover'		=> '#bbbbbb',
			'alter_bg_color'		=> '#efefef',
			'alter_bg_hover'		=> '#f0f0f0',
			)
		);

		// Add Custom fonts
		healthcoach_add_custom_font('h1', array(
			'title'			=> esc_html__('Heading 1', 'healthcoach'),
			'description'	=> '',
			'font-family'	=> 'Cabin',
			'font-size' 	=> '3.2em',
			'font-weight'	=> '600',
			'font-style'	=> '',
			'line-height'	=> '1.3em',
			'margin-top'	=> '0.28em',
			'margin-bottom'	=> '0.28em'
			)
		);
		healthcoach_add_custom_font('h2', array(
			'title'			=> esc_html__('Heading 2', 'healthcoach'),
			'description'	=> '',
			'font-family'	=> 'Cabin',
			'font-size' 	=> '2.4em',
			'font-weight'	=> '700',
			'font-style'	=> '',
			'line-height'	=> '1.3em',
			'margin-top'	=> '0.63em',
			'margin-bottom'	=> '0.63em'
			)
		);
		healthcoach_add_custom_font('h3', array(
			'title'			=> esc_html__('Heading 3', 'healthcoach'),
			'description'	=> '',
			'font-family'	=> 'Cabin',
			'font-size' 	=> '2em',
			'font-weight'	=> '600',
			'font-style'	=> '',
			'line-height'	=> '1.3em',
			'margin-top'	=> '1.05em',
			'margin-bottom'	=> '1.05em'
			)
		);
		healthcoach_add_custom_font('h4', array(
			'title'			=> esc_html__('Heading 4', 'healthcoach'),
			'description'	=> '',
			'font-family'	=> 'Cabin',
			'font-size' 	=> '1.65em',
			'font-weight'	=> '600',
			'font-style'	=> '',
			'line-height'	=> '1.3em',
			'margin-top'	=> '1.1em',
			'margin-bottom'	=> '1.1em'
			)
		);
		healthcoach_add_custom_font('h5', array(
			'title'			=> esc_html__('Heading 5', 'healthcoach'),
			'description'	=> '',
			'font-family'	=> 'Cabin',
			'font-size' 	=> '1.467em',
			'font-weight'	=> '600',
			'font-style'	=> '',
			'line-height'	=> '1.3em',
			'margin-top'	=> '1.3em',
			'margin-bottom'	=> '1.3em'
			)
		);
		healthcoach_add_custom_font('h6', array(
			'title'			=> esc_html__('Heading 6', 'healthcoach'),
			'description'	=> '',
			'font-family'	=> 'Cabin',
			'font-size' 	=> '1.2em',
			'font-weight'	=> '600',
			'font-style'	=> '',
			'line-height'	=> '1.3em',
			'margin-top'	=> '1.35em',
			'margin-bottom'	=> '1.35em'
			)
		);
		healthcoach_add_custom_font('p', array(
			'title'			=> esc_html__('Text', 'healthcoach'),
			'description'	=> '',
			'font-family'	=> 'Droid Serif',
			'font-size' 	=> '15px',
			'font-weight'	=> '400',
			'font-style'	=> '',
			'line-height'	=> '1.9em',
			'margin-top'	=> '',
			'margin-bottom'	=> '1.5em'
			)
		);
		healthcoach_add_custom_font('link', array(
			'title'			=> esc_html__('Links', 'healthcoach'),
			'description'	=> '',
			'font-family'	=> '',
			'font-size' 	=> '',
			'font-weight'	=> '',
			'font-style'	=> ''
			)
		);
		healthcoach_add_custom_font('info', array(
			'title'			=> esc_html__('Post info', 'healthcoach'),
			'description'	=> '',
			'font-family'	=> 'Cabin',
			'font-size' 	=> '0.933em',
			'font-weight'	=> '',
			'font-style'	=> '',
			'line-height'	=> '1.2857em',
			'margin-top'	=> '',
			'margin-bottom'	=> '1.5em'
			)
		);
		healthcoach_add_custom_font('menu', array(
			'title'			=> esc_html__('Main menu items', 'healthcoach'),
			'description'	=> '',
			'font-family'	=> 'Cabin',
			'font-size' 	=> '0.933em',
			'font-weight'	=> '700',
			'font-style'	=> '',
			'line-height'	=> '',
			'margin-top'	=> '1.8em',
			'margin-bottom'	=> '1.8em'
			)
		);
		healthcoach_add_custom_font('submenu', array(
			'title'			=> esc_html__('Dropdown menu items', 'healthcoach'),
			'description'	=> '',
			'font-family'	=> '',
			'font-size' 	=> '',
			'font-weight'	=> '600',
			'font-style'	=> '',
			'line-height'	=> '1.2857em',
			'margin-top'	=> '',
			'margin-bottom'	=> ''
			)
		);
		healthcoach_add_custom_font('logo', array(
			'title'			=> esc_html__('Logo', 'healthcoach'),
			'description'	=> '',
			'font-family'	=> '',
			'font-size' 	=> '2.8571em',
			'font-weight'	=> '700',
			'font-style'	=> '',
			'line-height'	=> '0.75em',
			'margin-top'	=> '1.35em',
			'margin-bottom'	=> '1em'
			)
		);
		healthcoach_add_custom_font('button', array(
			'title'			=> esc_html__('Buttons', 'healthcoach'),
			'description'	=> '',
			'font-family'	=> '',
			'font-size' 	=> '',
			'font-weight'	=> '',
			'font-style'	=> '',
			'line-height'	=> '1.2857em'
			)
		);
		healthcoach_add_custom_font('input', array(
			'title'			=> esc_html__('Input fields', 'healthcoach'),
			'description'	=> '',
			'font-family'	=> '',
			'font-size' 	=> '',
			'font-weight'	=> '',
			'font-style'	=> '',
			'line-height'	=> '1.2857em'
			)
		);

	}
}





//------------------------------------------------------------------------------
// Theme fonts
//------------------------------------------------------------------------------

// Add theme fonts in the used fonts list
if (!function_exists('healthcoach_filter_theme_styles_used_fonts')) {
	function healthcoach_filter_theme_styles_used_fonts($theme_fonts) {
		$theme_fonts['Cabin'] = 1;
		$theme_fonts['Droid Serif'] = 1;
		return $theme_fonts;
	}
}

if (!function_exists('healthcoach_filter_theme_styles_list_fonts')) {
	function healthcoach_filter_theme_styles_list_fonts($list) {
		if (!isset($list['Cabin']))	$list['Cabin'] = array('family'=>'sans-serif', 'link'=>'Cabin:400,600,700');
		if (!isset($list['Droid Serif']))	$list['Droid Serif'] = array('family'=>'serif', 'link'=>'Droid+Serif:400,700');
		return $list;
	}
}

//------------------------------------------------------------------------------
// Theme stylesheets
//------------------------------------------------------------------------------

// Add theme.less into list files for compilation
if (!function_exists('healthcoach_filter_theme_styles_compile_less')) {
	function healthcoach_filter_theme_styles_compile_less($files) {
		if (file_exists(healthcoach_get_file_dir('css/theme.less'))) {
		 	$files[] = healthcoach_get_file_dir('css/theme.less');
		}
		return $files;	
	}
}

// Add theme stylesheets
if (!function_exists('healthcoach_action_theme_styles_add_styles')) {
	function healthcoach_action_theme_styles_add_styles() {
		// Add stylesheet files only if LESS supported
		if ( healthcoach_get_theme_setting('less_compiler') != 'no' ) {
			wp_enqueue_style( 'healthcoach-theme-style', healthcoach_get_file_url('css/theme.css'), array(), null );
			wp_add_inline_style( 'healthcoach-theme-style', healthcoach_get_inline_css() );
		}
	}
}

// Add theme inline styles
if (!function_exists('healthcoach_filter_theme_styles_add_styles_inline')) {
	function healthcoach_filter_theme_styles_add_styles_inline($custom_style) {
		// Submenu width
		$menu_width = healthcoach_get_theme_option('menu_width');
		if (!empty($menu_width)) {
			$custom_style .= "
				/* Submenu width */
				.menu_side_nav > li ul,
				.menu_main_nav > li ul {
					width: ".intval($menu_width)."px;
				}
				.menu_side_nav > li > ul ul,
				.menu_main_nav > li > ul ul {
					left:".intval($menu_width+4)."px;
				}
				.menu_side_nav > li > ul ul.submenu_left,
				.menu_main_nav > li > ul ul.submenu_left {
					left:-".intval($menu_width+1)."px;
				}
			";
		}
	
		// Logo height
		$logo_height = healthcoach_get_custom_option('logo_height');
		if (!empty($logo_height)) {
			$custom_style .= "
				/* Logo header height */
				.sidebar_outer_logo .logo_main,
				.top_panel_wrap .logo_main,
				.top_panel_wrap .logo_fixed {
					height:".intval($logo_height)."px;
				}
			";
		}
	
		// Logo top offset
		$logo_offset = healthcoach_get_custom_option('logo_offset');
		if (!empty($logo_offset)) {
			$custom_style .= "
				/* Logo header top offset */
				.top_panel_wrap .logo {
					margin-top:".intval($logo_offset)."px;
				}
			";
		}

		// Logo footer height
		$logo_height = healthcoach_get_theme_option('logo_footer_height');
		if (!empty($logo_height)) {
			$custom_style .= "
				/* Logo footer height */
				.contacts_wrap .logo img {
					height:".intval($logo_height)."px;
				}
			";
		}

		return $custom_style;	
	}
}


//------------------------------------------------------------------------------
// Theme scripts
//------------------------------------------------------------------------------

// Add theme scripts
if (!function_exists('healthcoach_action_theme_styles_add_scripts')) {
	function healthcoach_action_theme_styles_add_scripts() {
		if (healthcoach_get_theme_option('show_theme_customizer') == 'yes' && file_exists(healthcoach_get_file_dir('js/theme.customizer.js')))
			wp_enqueue_script( 'healthcoach-theme_styles-customizer-script', healthcoach_get_file_url('js/theme.customizer.js'), array(), null, true );
	}
}

// Add theme scripts inline
if (!function_exists('healthcoach_filter_theme_styles_localize_script')) {
	function healthcoach_filter_theme_styles_localize_script($vars) {
		if (empty($vars['theme_font']))
			$vars['theme_font'] = healthcoach_get_custom_font_settings('p', 'font-family');
		$vars['theme_color'] = healthcoach_get_scheme_color('text_dark');
		$vars['theme_bg_color'] = healthcoach_get_scheme_color('bg_color');
		return $vars;
	}
}
?>