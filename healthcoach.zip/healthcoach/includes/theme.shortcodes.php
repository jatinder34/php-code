<?php
if (!function_exists('healthcoach_theme_shortcodes_setup')) {
	add_action( 'healthcoach_action_before_init_theme', 'healthcoach_theme_shortcodes_setup', 1 );
	function healthcoach_theme_shortcodes_setup() {
		add_filter('healthcoach_filter_googlemap_styles', 'healthcoach_theme_shortcodes_googlemap_styles');
	}
}


// Add theme-specific Google map styles
if ( !function_exists( 'healthcoach_theme_shortcodes_googlemap_styles' ) ) {
	function healthcoach_theme_shortcodes_googlemap_styles($list) {
		$list['simple']		= esc_html__('Simple', 'healthcoach');
		$list['greyscale']	= esc_html__('Greyscale', 'healthcoach');
		$list['inverse']	= esc_html__('Inverse', 'healthcoach');
		$list['apple']		= esc_html__('Apple', 'healthcoach');
		return $list;
	}
}
?>