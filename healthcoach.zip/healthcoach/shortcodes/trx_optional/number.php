<?php

/* Theme setup section
-------------------------------------------------------------------- */
if (!function_exists('healthcoach_sc_number_theme_setup')) {
	add_action( 'healthcoach_action_before_init_theme', 'healthcoach_sc_number_theme_setup' );
	function healthcoach_sc_number_theme_setup() {
		add_action('healthcoach_action_shortcodes_list', 		'healthcoach_sc_number_reg_shortcodes');
		if (function_exists('healthcoach_exists_visual_composer') && healthcoach_exists_visual_composer())
			add_action('healthcoach_action_shortcodes_list_vc','healthcoach_sc_number_reg_shortcodes_vc');
	}
}



/* Shortcode implementation
-------------------------------------------------------------------- */

/*
[trx_number id="unique_id" value="400"]
*/

if (!function_exists('healthcoach_sc_number')) {	
	function healthcoach_sc_number($atts, $content=null){	
		if (healthcoach_in_shortcode_blogger()) return '';
		extract(healthcoach_html_decode(shortcode_atts(array(
			// Individual params
			"value" => "",
			"align" => "",
			// Common params
			"id" => "",
			"class" => "",
			"animation" => "",
			"css" => "",
			"top" => "",
			"bottom" => "",
			"left" => "",
			"right" => ""
		), $atts)));
		$class .= ($class ? ' ' : '') . healthcoach_get_css_position_as_classes($top, $right, $bottom, $left);
		$output = '<div' . ($id ? ' id="'.esc_attr($id).'"' : '') 
				. ' class="sc_number' 
					. (!empty($align) ? ' align'.esc_attr($align) : '') 
					. (!empty($class) ? ' '.esc_attr($class) : '') 
					. '"'
				. (!healthcoach_param_is_off($animation) ? ' data-animation="'.esc_attr(healthcoach_get_animation_classes($animation)).'"' : '')
				. ($css!='' ? ' style="'.esc_attr($css).'"' : '')
				. '>';
		for ($i=0; $i < healthcoach_strlen($value); $i++) {
			$output .= '<span class="sc_number_item">' . trim(healthcoach_substr($value, $i, 1)) . '</span>';
		}
		$output .= '</div>';
		return apply_filters('healthcoach_shortcode_output', $output, 'trx_number', $atts, $content);
	}
	healthcoach_require_shortcode('trx_number', 'healthcoach_sc_number');
}



/* Register shortcode in the internal SC Builder
-------------------------------------------------------------------- */
if ( !function_exists( 'healthcoach_sc_number_reg_shortcodes' ) ) {
	//add_action('healthcoach_action_shortcodes_list', 'healthcoach_sc_number_reg_shortcodes');
	function healthcoach_sc_number_reg_shortcodes() {
	
		healthcoach_sc_map("trx_number", array(
			"title" => esc_html__("Number", 'healthcoach'),
			"desc" => wp_kses_data( __("Insert number or any word as set separate characters", 'healthcoach') ),
			"decorate" => false,
			"container" => false,
			"params" => array(
				"value" => array(
					"title" => esc_html__("Value", 'healthcoach'),
					"desc" => wp_kses_data( __("Number or any word", 'healthcoach') ),
					"value" => "",
					"type" => "text"
				),
				"align" => array(
					"title" => esc_html__("Align", 'healthcoach'),
					"desc" => wp_kses_data( __("Select block alignment", 'healthcoach') ),
					"value" => "none",
					"type" => "checklist",
					"dir" => "horizontal",
					"options" => healthcoach_get_sc_param('align')
				),
				"top" => healthcoach_get_sc_param('top'),
				"bottom" => healthcoach_get_sc_param('bottom'),
				"left" => healthcoach_get_sc_param('left'),
				"right" => healthcoach_get_sc_param('right'),
				"id" => healthcoach_get_sc_param('id'),
				"class" => healthcoach_get_sc_param('class'),
				"animation" => healthcoach_get_sc_param('animation'),
				"css" => healthcoach_get_sc_param('css')
			)
		));
	}
}


/* Register shortcode in the VC Builder
-------------------------------------------------------------------- */
if ( !function_exists( 'healthcoach_sc_number_reg_shortcodes_vc' ) ) {
	//add_action('healthcoach_action_shortcodes_list_vc', 'healthcoach_sc_number_reg_shortcodes_vc');
	function healthcoach_sc_number_reg_shortcodes_vc() {
	
		vc_map( array(
			"base" => "trx_number",
			"name" => esc_html__("Number", 'healthcoach'),
			"description" => wp_kses_data( __("Insert number or any word as set of separated characters", 'healthcoach') ),
			"category" => esc_html__('Content', 'healthcoach'),
			"class" => "trx_sc_single trx_sc_number",
			'icon' => 'icon_trx_number',
			"content_element" => true,
			"is_container" => false,
			"show_settings_on_create" => true,
			"params" => array(
				array(
					"param_name" => "value",
					"heading" => esc_html__("Value", 'healthcoach'),
					"description" => wp_kses_data( __("Number or any word to separate", 'healthcoach') ),
					"admin_label" => true,
					"class" => "",
					"value" => "",
					"type" => "textfield"
				),
				array(
					"param_name" => "align",
					"heading" => esc_html__("Alignment", 'healthcoach'),
					"description" => wp_kses_data( __("Select block alignment", 'healthcoach') ),
					"class" => "",
					"value" => array_flip(healthcoach_get_sc_param('align')),
					"type" => "dropdown"
				),
				healthcoach_get_vc_param('id'),
				healthcoach_get_vc_param('class'),
				healthcoach_get_vc_param('animation'),
				healthcoach_get_vc_param('css'),
				healthcoach_get_vc_param('margin_top'),
				healthcoach_get_vc_param('margin_bottom'),
				healthcoach_get_vc_param('margin_left'),
				healthcoach_get_vc_param('margin_right')
			)
		) );
		
		class WPBakeryShortCode_Trx_Number extends HEALTHCOACH_VC_ShortCodeSingle {}
	}
}
?>