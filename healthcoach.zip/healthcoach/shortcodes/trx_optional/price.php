<?php

/* Theme setup section
-------------------------------------------------------------------- */
if (!function_exists('healthcoach_sc_price_theme_setup')) {
	add_action( 'healthcoach_action_before_init_theme', 'healthcoach_sc_price_theme_setup' );
	function healthcoach_sc_price_theme_setup() {
		add_action('healthcoach_action_shortcodes_list', 		'healthcoach_sc_price_reg_shortcodes');
		if (function_exists('healthcoach_exists_visual_composer') && healthcoach_exists_visual_composer())
			add_action('healthcoach_action_shortcodes_list_vc','healthcoach_sc_price_reg_shortcodes_vc');
	}
}



/* Shortcode implementation
-------------------------------------------------------------------- */

/*
[trx_price id="unique_id" currency="$" money="29.99" period="monthly"]
*/

if (!function_exists('healthcoach_sc_price')) {	
	function healthcoach_sc_price($atts, $content=null){	
		if (healthcoach_in_shortcode_blogger()) return '';
		extract(healthcoach_html_decode(shortcode_atts(array(
			// Individual params
			"money" => "",
			"currency" => "$",
			"period" => "",
			"align" => "",
			// Common params
			"id" => "",
			"class" => "",
			"css" => "",
			"top" => "",
			"bottom" => "",
			"left" => "",
			"right" => ""
		), $atts)));
		$output = '';
		if (!empty($money)) {
			$class .= ($class ? ' ' : '') . healthcoach_get_css_position_as_classes($top, $right, $bottom, $left);
			$m = explode('.', str_replace(',', '.', $money));
			$output = '<div' . ($id ? ' id="'.esc_attr($id).'"' : '') 
					. ' class="sc_price'
					. (!empty($class) ? ' '.esc_attr($class) : '')
					. ($align && $align!='none' ? ' align'.esc_attr($align) : '') 
					. '"'
					. ($css!='' ? ' style="'.esc_attr($css).'"' : '')
					. '>'
				. '<span class="sc_price_currency">'.($currency).'</span>'
				. '<span class="sc_price_money">'.($m[0]).'</span>'
				. (!empty($m[1]) ? '<span class="sc_price_info">' : '')
				. (!empty($m[1]) ? '<span class="sc_price_penny">'.($m[1]).'</span>' : '')
				. (!empty($period) ? '<span class="sc_price_period">'.($period).'</span>' : (!empty($m[1]) ? '<span class="sc_price_period_empty"></span>' : ''))
				. (!empty($m[1]) ? '</span>' : '')
				. '</div>';
		}
		return apply_filters('healthcoach_shortcode_output', $output, 'trx_price', $atts, $content);
	}
	healthcoach_require_shortcode('trx_price', 'healthcoach_sc_price');
}



/* Register shortcode in the internal SC Builder
-------------------------------------------------------------------- */
if ( !function_exists( 'healthcoach_sc_price_reg_shortcodes' ) ) {
	//add_action('healthcoach_action_shortcodes_list', 'healthcoach_sc_price_reg_shortcodes');
	function healthcoach_sc_price_reg_shortcodes() {
	
		healthcoach_sc_map("trx_price", array(
			"title" => esc_html__("Price", 'healthcoach'),
			"desc" => wp_kses_data( __("Insert price with decoration", 'healthcoach') ),
			"decorate" => false,
			"container" => false,
			"params" => array(
				"money" => array(
					"title" => esc_html__("Money", 'healthcoach'),
					"desc" => wp_kses_data( __("Money value (dot or comma separated)", 'healthcoach') ),
					"value" => "",
					"type" => "text"
				),
				"currency" => array(
					"title" => esc_html__("Currency", 'healthcoach'),
					"desc" => wp_kses_data( __("Currency character", 'healthcoach') ),
					"value" => "$",
					"type" => "text"
				),
				"period" => array(
					"title" => esc_html__("Period", 'healthcoach'),
					"desc" => wp_kses_data( __("Period text (if need). For example: monthly, daily, etc.", 'healthcoach') ),
					"value" => "",
					"type" => "text"
				),
				"align" => array(
					"title" => esc_html__("Alignment", 'healthcoach'),
					"desc" => wp_kses_data( __("Align price to left or right side", 'healthcoach') ),
					"value" => "",
					"type" => "checklist",
					"dir" => "horizontal",
					"options" => healthcoach_get_sc_param('float')
				), 
				"top" => healthcoach_get_sc_param('top'),
				"bottom" => healthcoach_get_sc_param('bottom'),
				"left" => healthcoach_get_sc_param('left'),
				"right" => healthcoach_get_sc_param('right'),
				"id" => healthcoach_get_sc_param('id'),
				"class" => healthcoach_get_sc_param('class'),
				"css" => healthcoach_get_sc_param('css')
			)
		));
	}
}


/* Register shortcode in the VC Builder
-------------------------------------------------------------------- */
if ( !function_exists( 'healthcoach_sc_price_reg_shortcodes_vc' ) ) {
	//add_action('healthcoach_action_shortcodes_list_vc', 'healthcoach_sc_price_reg_shortcodes_vc');
	function healthcoach_sc_price_reg_shortcodes_vc() {
	
		vc_map( array(
			"base" => "trx_price",
			"name" => esc_html__("Price", 'healthcoach'),
			"description" => wp_kses_data( __("Insert price with decoration", 'healthcoach') ),
			"category" => esc_html__('Content', 'healthcoach'),
			'icon' => 'icon_trx_price',
			"class" => "trx_sc_single trx_sc_price",
			"content_element" => true,
			"is_container" => false,
			"show_settings_on_create" => true,
			"params" => array(
				array(
					"param_name" => "money",
					"heading" => esc_html__("Money", 'healthcoach'),
					"description" => wp_kses_data( __("Money value (dot or comma separated)", 'healthcoach') ),
					"admin_label" => true,
					"class" => "",
					"value" => "",
					"type" => "textfield"
				),
				array(
					"param_name" => "currency",
					"heading" => esc_html__("Currency symbol", 'healthcoach'),
					"description" => wp_kses_data( __("Currency character", 'healthcoach') ),
					"admin_label" => true,
					"class" => "",
					"value" => "$",
					"type" => "textfield"
				),
				array(
					"param_name" => "period",
					"heading" => esc_html__("Period", 'healthcoach'),
					"description" => wp_kses_data( __("Period text (if need). For example: monthly, daily, etc.", 'healthcoach') ),
					"admin_label" => true,
					"class" => "",
					"value" => "",
					"type" => "textfield"
				),
				array(
					"param_name" => "align",
					"heading" => esc_html__("Alignment", 'healthcoach'),
					"description" => wp_kses_data( __("Align price to left or right side", 'healthcoach') ),
					"admin_label" => true,
					"class" => "",
					"value" => array_flip(healthcoach_get_sc_param('float')),
					"type" => "dropdown"
				),
				healthcoach_get_vc_param('id'),
				healthcoach_get_vc_param('class'),
				healthcoach_get_vc_param('css'),
				healthcoach_get_vc_param('margin_top'),
				healthcoach_get_vc_param('margin_bottom'),
				healthcoach_get_vc_param('margin_left'),
				healthcoach_get_vc_param('margin_right')
			)
		) );
		
		class WPBakeryShortCode_Trx_Price extends HEALTHCOACH_VC_ShortCodeSingle {}
	}
}
?>