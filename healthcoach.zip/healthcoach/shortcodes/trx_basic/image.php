<?php

/* Theme setup section
-------------------------------------------------------------------- */
if (!function_exists('healthcoach_sc_image_theme_setup')) {
	add_action( 'healthcoach_action_before_init_theme', 'healthcoach_sc_image_theme_setup' );
	function healthcoach_sc_image_theme_setup() {
		add_action('healthcoach_action_shortcodes_list', 		'healthcoach_sc_image_reg_shortcodes');
		if (function_exists('healthcoach_exists_visual_composer') && healthcoach_exists_visual_composer())
			add_action('healthcoach_action_shortcodes_list_vc','healthcoach_sc_image_reg_shortcodes_vc');
	}
}



/* Shortcode implementation
-------------------------------------------------------------------- */

/*
[trx_image id="unique_id" src="image_url" width="width_in_pixels" height="height_in_pixels" title="image's_title" align="left|right"]
*/

if (!function_exists('healthcoach_sc_image')) {	
	function healthcoach_sc_image($atts, $content=null){	
		if (healthcoach_in_shortcode_blogger()) return '';
		extract(healthcoach_html_decode(shortcode_atts(array(
			// Individual params
			"title" => "",
			"align" => "",
			"shape" => "square",
			"src" => "",
			"url" => "",
			"icon" => "",
			"link" => "",
			// Common params
			"id" => "",
			"class" => "",
			"animation" => "",
			"css" => "",
			"top" => "",
			"bottom" => "",
			"left" => "",
			"right" => "",
			"width" => "",
			"height" => ""
		), $atts)));
		$class .= ($class ? ' ' : '') . healthcoach_get_css_position_as_classes($top, $right, $bottom, $left);
		$css .= healthcoach_get_css_dimensions_from_values($width, $height);
		$src = $src!='' ? $src : $url;
		if ($src > 0) {
			$attach = wp_get_attachment_image_src( $src, 'full' );
			if (isset($attach[0]) && $attach[0]!='')
				$src = $attach[0];
		}
		if (!empty($width) || !empty($height)) {
			$w = !empty($width) && strlen(intval($width)) == strlen($width) ? $width : null;
			$h = !empty($height) && strlen(intval($height)) == strlen($height) ? $height : null;
			if ($w || $h) $src = healthcoach_get_resized_image_url($src, $w, $h);
		}
		if (trim($link)) healthcoach_enqueue_popup();
		$output = empty($src) ? '' : ('<figure' . ($id ? ' id="'.esc_attr($id).'"' : '') 
			. ' class="sc_image ' . ($align && $align!='none' ? ' align' . esc_attr($align) : '') . (!empty($shape) ? ' sc_image_shape_'.esc_attr($shape) : '') . (!empty($class) ? ' '.esc_attr($class) : '') . '"'
			. (!healthcoach_param_is_off($animation) ? ' data-animation="'.esc_attr(healthcoach_get_animation_classes($animation)).'"' : '')
			. ($css!='' ? ' style="'.esc_attr($css).'"' : '')
			. '>'
				. (trim($link) ? '<a href="'.esc_url($link).'">' : '')
				. '<img src="'.esc_url($src).'" alt="" />'
				. (trim($link) ? '</a>' : '')
				. (trim($title) || trim($icon) ? '<figcaption><span'.($icon ? ' class="'.esc_attr($icon).'"' : '').'></span> ' . ($title) . '</figcaption>' : '')
			. '</figure>');
		return apply_filters('healthcoach_shortcode_output', $output, 'trx_image', $atts, $content);
	}
	healthcoach_require_shortcode('trx_image', 'healthcoach_sc_image');
}



/* Register shortcode in the internal SC Builder
-------------------------------------------------------------------- */
if ( !function_exists( 'healthcoach_sc_image_reg_shortcodes' ) ) {
	//add_action('healthcoach_action_shortcodes_list', 'healthcoach_sc_image_reg_shortcodes');
	function healthcoach_sc_image_reg_shortcodes() {
	
		healthcoach_sc_map("trx_image", array(
			"title" => esc_html__("Image", 'healthcoach'),
			"desc" => wp_kses_data( __("Insert image into your post (page)", 'healthcoach') ),
			"decorate" => false,
			"container" => false,
			"params" => array(
				"url" => array(
					"title" => esc_html__("URL for image file", 'healthcoach'),
					"desc" => wp_kses_data( __("Select or upload image or write URL from other site", 'healthcoach') ),
					"readonly" => false,
					"value" => "",
					"type" => "media",
					"before" => array(
						'sizes' => true		// If you want allow user select thumb size for image. Otherwise, thumb size is ignored - image fullsize used
					)
				),
				"title" => array(
					"title" => esc_html__("Title", 'healthcoach'),
					"desc" => wp_kses_data( __("Image title (if need)", 'healthcoach') ),
					"value" => "",
					"type" => "text"
				),
				"icon" => array(
					"title" => esc_html__("Icon before title",  'healthcoach'),
					"desc" => wp_kses_data( __('Select icon for the title from Fontello icons set',  'healthcoach') ),
					"value" => "",
					"type" => "icons",
					"options" => healthcoach_get_sc_param('icons')
				),
				"align" => array(
					"title" => esc_html__("Float image", 'healthcoach'),
					"desc" => wp_kses_data( __("Float image to left or right side", 'healthcoach') ),
					"value" => "",
					"type" => "checklist",
					"dir" => "horizontal",
					"options" => healthcoach_get_sc_param('float')
				), 
				"shape" => array(
					"title" => esc_html__("Image Shape", 'healthcoach'),
					"desc" => wp_kses_data( __("Shape of the image: square (rectangle) or round", 'healthcoach') ),
					"value" => "square",
					"type" => "checklist",
					"dir" => "horizontal",
					"options" => array(
						"square" => esc_html__('Square', 'healthcoach'),
						"round" => esc_html__('Round', 'healthcoach')
					)
				), 
				"link" => array(
					"title" => esc_html__("Link", 'healthcoach'),
					"desc" => wp_kses_data( __("The link URL from the image", 'healthcoach') ),
					"value" => "",
					"type" => "text"
				),
				"width" => healthcoach_shortcodes_width(),
				"height" => healthcoach_shortcodes_height(),
				"top" => healthcoach_get_sc_param('top'),
				"bottom" => healthcoach_get_sc_param('bottom'),
				"left" => healthcoach_get_sc_param('left'),
				"right" => healthcoach_get_sc_param('right'),
				"id" => healthcoach_get_sc_param('id'),
				"class" => healthcoach_get_sc_param('class'),
				"animation" => healthcoach_get_sc_param('animation'),
				"css" => healthcoach_get_sc_param('css')
			)
		));
	}
}


/* Register shortcode in the VC Builder
-------------------------------------------------------------------- */
if ( !function_exists( 'healthcoach_sc_image_reg_shortcodes_vc' ) ) {
	//add_action('healthcoach_action_shortcodes_list_vc', 'healthcoach_sc_image_reg_shortcodes_vc');
	function healthcoach_sc_image_reg_shortcodes_vc() {
	
		vc_map( array(
			"base" => "trx_image",
			"name" => esc_html__("Image", 'healthcoach'),
			"description" => wp_kses_data( __("Insert image", 'healthcoach') ),
			"category" => esc_html__('Content', 'healthcoach'),
			'icon' => 'icon_trx_image',
			"class" => "trx_sc_single trx_sc_image",
			"content_element" => true,
			"is_container" => false,
			"show_settings_on_create" => true,
			"params" => array(
				array(
					"param_name" => "url",
					"heading" => esc_html__("Select image", 'healthcoach'),
					"description" => wp_kses_data( __("Select image from library", 'healthcoach') ),
					"admin_label" => true,
					"class" => "",
					"value" => "",
					"type" => "attach_image"
				),
				array(
					"param_name" => "align",
					"heading" => esc_html__("Image alignment", 'healthcoach'),
					"description" => wp_kses_data( __("Align image to left or right side", 'healthcoach') ),
					"admin_label" => true,
					"class" => "",
					"value" => array_flip(healthcoach_get_sc_param('float')),
					"type" => "dropdown"
				),
				array(
					"param_name" => "shape",
					"heading" => esc_html__("Image shape", 'healthcoach'),
					"description" => wp_kses_data( __("Shape of the image: square or round", 'healthcoach') ),
					"admin_label" => true,
					"class" => "",
					"value" => array(
						esc_html__('Square', 'healthcoach') => 'square',
						esc_html__('Round', 'healthcoach') => 'round'
					),
					"type" => "dropdown"
				),
				array(
					"param_name" => "title",
					"heading" => esc_html__("Title", 'healthcoach'),
					"description" => wp_kses_data( __("Image's title", 'healthcoach') ),
					"admin_label" => true,
					"class" => "",
					"value" => "",
					"type" => "textfield"
				),
				array(
					"param_name" => "icon",
					"heading" => esc_html__("Title's icon", 'healthcoach'),
					"description" => wp_kses_data( __("Select icon for the title from Fontello icons set", 'healthcoach') ),
					"class" => "",
					"value" => healthcoach_get_sc_param('icons'),
					"type" => "dropdown"
				),
				array(
					"param_name" => "link",
					"heading" => esc_html__("Link", 'healthcoach'),
					"description" => wp_kses_data( __("The link URL from the image", 'healthcoach') ),
					"admin_label" => true,
					"class" => "",
					"value" => "",
					"type" => "textfield"
				),
				healthcoach_get_vc_param('id'),
				healthcoach_get_vc_param('class'),
				healthcoach_get_vc_param('animation'),
				healthcoach_get_vc_param('css'),
				healthcoach_vc_width(),
				healthcoach_vc_height(),
				healthcoach_get_vc_param('margin_top'),
				healthcoach_get_vc_param('margin_bottom'),
				healthcoach_get_vc_param('margin_left'),
				healthcoach_get_vc_param('margin_right')
			)
		) );
		
		class WPBakeryShortCode_Trx_Image extends HEALTHCOACH_VC_ShortCodeSingle {}
	}
}
?>