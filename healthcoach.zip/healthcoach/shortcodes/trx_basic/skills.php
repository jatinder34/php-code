<?php

/* Theme setup section
-------------------------------------------------------------------- */
if (!function_exists('healthcoach_sc_skills_theme_setup')) {
	add_action( 'healthcoach_action_before_init_theme', 'healthcoach_sc_skills_theme_setup' );
	function healthcoach_sc_skills_theme_setup() {
		add_action('healthcoach_action_shortcodes_list', 		'healthcoach_sc_skills_reg_shortcodes');
		if (function_exists('healthcoach_exists_visual_composer') && healthcoach_exists_visual_composer())
			add_action('healthcoach_action_shortcodes_list_vc','healthcoach_sc_skills_reg_shortcodes_vc');
	}
}



/* Shortcode implementation
-------------------------------------------------------------------- */

/*
[trx_skills id="unique_id" type="bar|pie|arc|counter" dir="horizontal|vertical" layout="rows|columns" count="" max_value="100" align="left|right"]
	[trx_skills_item title="Scelerisque pid" value="50%"]
	[trx_skills_item title="Scelerisque pid" value="50%"]
	[trx_skills_item title="Scelerisque pid" value="50%"]
[/trx_skills]
*/

if (!function_exists('healthcoach_sc_skills')) {	
	function healthcoach_sc_skills($atts, $content=null){	
		if (healthcoach_in_shortcode_blogger()) return '';
		extract(healthcoach_html_decode(shortcode_atts(array(
			// Individual params
			"max_value" => "100",
			"type" => "bar",
			"layout" => "",
			"dir" => "",
			"style" => "1",
			"columns" => "",
			"align" => "",
			"color" => "",
			"bg_color" => "",
			"border_color" => "",
			"arc_caption" => esc_html__("Skills", 'healthcoach'),
			"pie_compact" => "on",
			"pie_cutout" => 0,
			"title" => "",
			"subtitle" => "",
			"description" => "",
			"link_caption" => esc_html__('Learn more', 'healthcoach'),
			"link" => '',
			// Common params
			"id" => "",
			"class" => "",
			"animation" => "",
			"css" => "",
			"width" => "",
			"height" => "",
			"top" => "",
			"bottom" => "",
			"left" => "",
			"right" => ""
		), $atts)));
		healthcoach_storage_set('sc_skills_data', array(
			'counter' => 0,
            'columns' => 0,
            'height'  => 0,
            'type'    => $type,
            'pie_compact' => healthcoach_param_is_on($pie_compact) ? 'on' : 'off',
            'pie_cutout'  => max(0, min(99, $pie_cutout)),
            'color'   => $color,
            'bg_color'=> $bg_color,
            'border_color'=> $border_color,
            'legend'  => '',
            'data'    => ''
			)
		);
		healthcoach_enqueue_diagram($type);
		if ($type!='arc') {
			if ($layout=='' || ($layout=='columns' && $columns<1)) $layout = 'rows';
			if ($layout=='columns') healthcoach_storage_set_array('sc_skills_data', 'columns', $columns);
			if ($type=='bar') {
				if ($dir == '') $dir = 'horizontal';
				if ($dir == 'vertical' && $height < 1) $height = 300;
			}
		}
		if (empty($id)) $id = 'sc_skills_diagram_'.str_replace('.','',mt_rand());
		if ($max_value < 1) $max_value = 100;
		if ($style) {
			$style = max(1, min(4, $style));
			healthcoach_storage_set_array('sc_skills_data', 'style', $style);
		}
		healthcoach_storage_set_array('sc_skills_data', 'max', $max_value);
		healthcoach_storage_set_array('sc_skills_data', 'dir', $dir);
		healthcoach_storage_set_array('sc_skills_data', 'height', healthcoach_prepare_css_value($height));
		$class .= ($class ? ' ' : '') . healthcoach_get_css_position_as_classes($top, $right, $bottom, $left);
		$css .= healthcoach_get_css_dimensions_from_values($width);
		if (!healthcoach_storage_empty('sc_skills_data', 'height') && (healthcoach_storage_get_array('sc_skills_data', 'type') == 'arc' || (healthcoach_storage_get_array('sc_skills_data', 'type') == 'pie' && healthcoach_param_is_on(healthcoach_storage_get_array('sc_skills_data', 'pie_compact')))))
			$css .= 'height: '.healthcoach_storage_get_array('sc_skills_data', 'height');
		$content = do_shortcode($content);
		$output = '<div id="'.esc_attr($id).'"' 
					. ' class="sc_skills sc_skills_' . esc_attr($type) 
						. ($type=='bar' ? ' sc_skills_'.esc_attr($dir) : '') 
						. ($type=='pie' ? ' sc_skills_compact_'.esc_attr(healthcoach_storage_get_array('sc_skills_data', 'pie_compact')) : '') 
						. (!empty($class) ? ' '.esc_attr($class) : '') 
						. ($align && $align!='none' ? ' align'.esc_attr($align) : '') 
						. '"'
					. ($css!='' ? ' style="'.esc_attr($css).'"' : '')
					. (!healthcoach_param_is_off($animation) ? ' data-animation="'.esc_attr(healthcoach_get_animation_classes($animation)).'"' : '')
					. ' data-type="'.esc_attr($type).'"'
					. ' data-caption="'.esc_attr($arc_caption).'"'
					. ($type=='bar' ? ' data-dir="'.esc_attr($dir).'"' : '')
				. '>'
					. (!empty($subtitle) ? '<h6 class="sc_skills_subtitle sc_item_subtitle">' . esc_html($subtitle) . '</h6>' : '')
					. (!empty($title) ? '<h2 class="sc_skills_title sc_item_title">' . esc_html($title) . '</h2>' : '')
					. (!empty($description) ? '<div class="sc_skills_descr sc_item_descr">' . trim($description) . '</div>' : '')
					. ($layout == 'columns' ? '<div class="columns_wrap sc_skills_'.esc_attr($layout).' sc_skills_columns_'.esc_attr($columns).'">' : '')
					. ($type=='arc' 
						? ('<div class="sc_skills_legend">'.(healthcoach_storage_get_array('sc_skills_data', 'legend')).'</div>'
							. '<div id="'.esc_attr($id).'_diagram" class="sc_skills_arc_canvas"></div>'
							. '<div class="sc_skills_data" style="display:none;">' . (healthcoach_storage_get_array('sc_skills_data', 'data')) . '</div>'
						  )
						: '')
					. ($type=='pie' && healthcoach_param_is_on(healthcoach_storage_get_array('sc_skills_data', 'pie_compact'))
						? ('<div class="sc_skills_legend">'.(healthcoach_storage_get_array('sc_skills_data', 'legend')).'</div>'
							. '<div id="'.esc_attr($id).'_pie" class="sc_skills_item">'
								. '<canvas id="'.esc_attr($id).'_pie_canvas" class="sc_skills_pie_canvas"></canvas>'
								. '<div class="sc_skills_data" style="display:none;">' . (healthcoach_storage_get_array('sc_skills_data', 'data')) . '</div>'
							. '</div>'
						  )
						: '')
					. ($content)
					. ($layout == 'columns' ? '</div>' : '')
					. (!empty($link) ? '<div class="sc_skills_button sc_item_button">'.do_shortcode('[trx_button link="'.esc_url($link).'" icon="icon-right"]'.esc_html($link_caption).'[/trx_button]').'</div>' : '')
				. '</div>';
		return apply_filters('healthcoach_shortcode_output', $output, 'trx_skills', $atts, $content);
	}
	healthcoach_require_shortcode('trx_skills', 'healthcoach_sc_skills');
}


if (!function_exists('healthcoach_sc_skills_item')) {	
	function healthcoach_sc_skills_item($atts, $content=null) {
		if (healthcoach_in_shortcode_blogger()) return '';
		extract(healthcoach_html_decode(shortcode_atts( array(
			// Individual params
			"title" => "",
			"value" => "",
			"color" => "",
			"bg_color" => "",
			"border_color" => "",
			"style" => "",
			"icon" => "",
			// Common params
			"id" => "",
			"class" => "",
			"css" => ""
		), $atts)));
		healthcoach_storage_inc_array('sc_skills_data', 'counter');
		$ed = healthcoach_substr($value, -1)=='%' ? '%' : '';
		$value = str_replace('%', '', $value);
		if (healthcoach_storage_get_array('sc_skills_data', 'max') < $value) healthcoach_storage_set_array('sc_skills_data', 'max', $value);
		$percent = round($value / healthcoach_storage_get_array('sc_skills_data', 'max') * 100);
		$start = 0;
		$stop = $value;
		$steps = 100;
		$step = max(1, round(healthcoach_storage_get_array('sc_skills_data', 'max')/$steps));
		$speed = mt_rand(10,40);
		$animation = round(($stop - $start) / $step * $speed);
		$title_block = '<div class="sc_skills_info"><div class="sc_skills_label">' . ($title) . '</div></div>';
		$old_color = $color;
		if (empty($color)) $color = healthcoach_storage_get_array('sc_skills_data', 'color');
		if (empty($color)) $color = healthcoach_get_scheme_color('text_link', $color);
		if (empty($bg_color)) $bg_color = healthcoach_storage_get_array('sc_skills_data', 'bg_color');
		if (empty($bg_color)) $bg_color = healthcoach_get_scheme_color('bg_color', $bg_color);
		if (empty($border_color)) $border_color = healthcoach_storage_get_array('sc_skills_data', 'border_color');
		if (empty($border_color)) $border_color = healthcoach_get_scheme_color('bd_color', $border_color);;
		if (empty($style)) $style = healthcoach_storage_get_array('sc_skills_data', 'style');
		$style = max(1, min(4, $style));
		$output = '';
		if (healthcoach_storage_get_array('sc_skills_data', 'type') == 'arc' || (healthcoach_storage_get_array('sc_skills_data', 'type') == 'pie' && healthcoach_param_is_on(healthcoach_storage_get_array('sc_skills_data', 'pie_compact')))) {
			if (healthcoach_storage_get_array('sc_skills_data', 'type') == 'arc' && empty($old_color)) {
				$rgb = healthcoach_hex2rgb($color);
				$color = 'rgba('.(int)$rgb['r'].','.(int)$rgb['g'].','.(int)$rgb['b'].','.(1 - 0.1*(healthcoach_storage_get_array('sc_skills_data', 'counter')-1)).')';
			}
			healthcoach_storage_concat_array('sc_skills_data', 'legend', 
				'<div class="sc_skills_legend_item"><span class="sc_skills_legend_marker" style="background-color:'.esc_attr($color).'"></span><span class="sc_skills_legend_title">' . ($title) . '</span><span class="sc_skills_legend_value">' . ($value) . '</span></div>'
			);
			healthcoach_storage_concat_array('sc_skills_data', 'data', 
				'<div' . ($id ? ' id="'.esc_attr($id).'"' : '')
					. ' class="'.esc_attr(healthcoach_storage_get_array('sc_skills_data', 'type')).'"'
					. (healthcoach_storage_get_array('sc_skills_data', 'type')=='pie'
						? ( ' data-start="'.esc_attr($start).'"'
							. ' data-stop="'.esc_attr($stop).'"'
							. ' data-step="'.esc_attr($step).'"'
							. ' data-steps="'.esc_attr($steps).'"'
							. ' data-max="'.esc_attr(healthcoach_storage_get_array('sc_skills_data', 'max')).'"'
							. ' data-speed="'.esc_attr($speed).'"'
							. ' data-duration="'.esc_attr($animation).'"'
							. ' data-color="'.esc_attr($color).'"'
							. ' data-bg_color="'.esc_attr($bg_color).'"'
							. ' data-border_color="'.esc_attr($border_color).'"'
							. ' data-cutout="'.esc_attr(healthcoach_storage_get_array('sc_skills_data', 'pie_cutout')).'"'
							. ' data-easing="easeOutCirc"'
							. ' data-ed="'.esc_attr($ed).'"'
							)
						: '')
					. '><input type="hidden" class="text" value="'.esc_attr($title).'" /><input type="hidden" class="percent" value="'.esc_attr($percent).'" /><input type="hidden" class="color" value="'.esc_attr($color).'" /></div>'
			);
		} else {
			$output .= (healthcoach_storage_get_array('sc_skills_data', 'columns') > 0 
							? '<div class="sc_skills_column column-1_'.esc_attr(healthcoach_storage_get_array('sc_skills_data', 'columns')).'">' 
							: '')
					. (healthcoach_storage_get_array('sc_skills_data', 'type')=='bar' && healthcoach_storage_get_array('sc_skills_data', 'dir')=='horizontal' ? $title_block : '')
					. '<div' . ($id ? ' id="'.esc_attr($id).'"' : '') 
						. ' class="sc_skills_item' . ($style ? ' sc_skills_style_'.esc_attr($style) : '') 
							. (!empty($class) ? ' '.esc_attr($class) : '')
							. (healthcoach_storage_get_array('sc_skills_data', 'counter') % 2 == 1 ? ' odd' : ' even') 
							. (healthcoach_storage_get_array('sc_skills_data', 'counter') == 1 ? ' first' : '') 
							. '"'
						. (healthcoach_storage_get_array('sc_skills_data', 'height') !='' || $css 
							? ' style="' 
								. (healthcoach_storage_get_array('sc_skills_data', 'height') !='' 
										? 'height: '.esc_attr(healthcoach_storage_get_array('sc_skills_data', 'height')).';' 
										: '') 
								. ($css) 
								. '"' 
							: '')
					. '>'
					. (!empty($icon) ? '<div class="sc_skills_icon '.esc_attr($icon).'"></div>' : '');
			if (in_array(healthcoach_storage_get_array('sc_skills_data', 'type'), array('bar', 'counter'))) {
				$output .= '<div class="sc_skills_count"' . (healthcoach_storage_get_array('sc_skills_data', 'type')=='bar' && $color ? ' style="background-color:' . esc_attr($color) . '; border-color:' . esc_attr($color) . '"' : '') . '>'
							. '<div class="sc_skills_total"'
								. ' data-start="'.esc_attr($start).'"'
								. ' data-stop="'.esc_attr($stop).'"'
								. ' data-step="'.esc_attr($step).'"'
								. ' data-max="'.esc_attr(healthcoach_storage_get_array('sc_skills_data', 'max')).'"'
								. ' data-speed="'.esc_attr($speed).'"'
								. ' data-duration="'.esc_attr($animation).'"'
								. ' data-ed="'.esc_attr($ed).'">'
								. ($start) . ($ed)
							.'</div>'
						. '</div>';
			} else if (healthcoach_storage_get_array('sc_skills_data', 'type')=='pie') {
				if (empty($id)) $id = 'sc_skills_canvas_'.str_replace('.','',mt_rand());
				$output .= '<canvas id="'.esc_attr($id).'_canvas"></canvas>'
					. '<div class="sc_skills_total"'
						. ' data-start="'.esc_attr($start).'"'
						. ' data-stop="'.esc_attr($stop).'"'
						. ' data-step="'.esc_attr($step).'"'
						. ' data-steps="'.esc_attr($steps).'"'
						. ' data-max="'.esc_attr(healthcoach_storage_get_array('sc_skills_data', 'max')).'"'
						. ' data-speed="'.esc_attr($speed).'"'
						. ' data-duration="'.esc_attr($animation).'"'
						. ' data-color="'.esc_attr($color).'"'
						. ' data-bg_color="'.esc_attr($bg_color).'"'
						. ' data-border_color="'.esc_attr($border_color).'"'
						. ' data-cutout="'.esc_attr(healthcoach_storage_get_array('sc_skills_data', 'pie_cutout')).'"'
						. ' data-easing="easeOutCirc"'
						. ' data-ed="'.esc_attr($ed).'">'
						. ($start) . ($ed)
					.'</div>';
			}
			$output .= 
					  (healthcoach_storage_get_array('sc_skills_data', 'type')=='counter' ? $title_block : '')
					. '</div>'
					. (healthcoach_storage_get_array('sc_skills_data', 'type')=='bar' && healthcoach_storage_get_array('sc_skills_data', 'dir')=='vertical' || healthcoach_storage_get_array('sc_skills_data', 'type') == 'pie' ? $title_block : '')
					. (healthcoach_storage_get_array('sc_skills_data', 'columns') > 0 ? '</div>' : '');
		}
		return apply_filters('healthcoach_shortcode_output', $output, 'trx_skills_item', $atts, $content);
	}
	healthcoach_require_shortcode('trx_skills_item', 'healthcoach_sc_skills_item');
}



/* Register shortcode in the internal SC Builder
-------------------------------------------------------------------- */
if ( !function_exists( 'healthcoach_sc_skills_reg_shortcodes' ) ) {
	//add_action('healthcoach_action_shortcodes_list', 'healthcoach_sc_skills_reg_shortcodes');
	function healthcoach_sc_skills_reg_shortcodes() {
	
		healthcoach_sc_map("trx_skills", array(
			"title" => esc_html__("Skills", 'healthcoach'),
			"desc" => wp_kses_data( __("Insert skills diagramm in your page (post)", 'healthcoach') ),
			"decorate" => true,
			"container" => false,
			"params" => array(
				"max_value" => array(
					"title" => esc_html__("Max value", 'healthcoach'),
					"desc" => wp_kses_data( __("Max value for skills items", 'healthcoach') ),
					"value" => 100,
					"min" => 1,
					"type" => "spinner"
				),
				"type" => array(
					"title" => esc_html__("Skills type", 'healthcoach'),
					"desc" => wp_kses_data( __("Select type of skills block", 'healthcoach') ),
					"value" => "bar",
					"type" => "checklist",
					"dir" => "horizontal",
					"options" => array(
						'bar' => esc_html__('Bar', 'healthcoach'),
						'pie' => esc_html__('Pie chart', 'healthcoach'),
						'counter' => esc_html__('Counter', 'healthcoach'),
						'arc' => esc_html__('Arc', 'healthcoach')
					)
				), 
				"layout" => array(
					"title" => esc_html__("Skills layout", 'healthcoach'),
					"desc" => wp_kses_data( __("Select layout of skills block", 'healthcoach') ),
					"dependency" => array(
						'type' => array('counter','pie','bar')
					),
					"value" => "rows",
					"type" => "checklist",
					"dir" => "horizontal",
					"options" => array(
						'rows' => esc_html__('Rows', 'healthcoach'),
						'columns' => esc_html__('Columns', 'healthcoach')
					)
				),
				"dir" => array(
					"title" => esc_html__("Direction", 'healthcoach'),
					"desc" => wp_kses_data( __("Select direction of skills block", 'healthcoach') ),
					"dependency" => array(
						'type' => array('counter','pie','bar')
					),
					"value" => "horizontal",
					"type" => "checklist",
					"dir" => "horizontal",
					"options" => healthcoach_get_sc_param('dir')
				), 
				"style" => array(
					"title" => esc_html__("Counters style", 'healthcoach'),
					"desc" => wp_kses_data( __("Select style of skills items (only for type=counter)", 'healthcoach') ),
					"dependency" => array(
						'type' => array('counter')
					),
					"value" => 1,
					"options" => healthcoach_get_list_styles(1, 4),
					"type" => "checklist"
				), 
				// "columns" - autodetect, not set manual
				"color" => array(
					"title" => esc_html__("Skills items color", 'healthcoach'),
					"desc" => wp_kses_data( __("Color for all skills items", 'healthcoach') ),
					"divider" => true,
					"value" => "",
					"type" => "color"
				),
				"bg_color" => array(
					"title" => esc_html__("Background color", 'healthcoach'),
					"desc" => wp_kses_data( __("Background color for all skills items (only for type=pie)", 'healthcoach') ),
					"dependency" => array(
						'type' => array('pie')
					),
					"value" => "",
					"type" => "color"
				),
				"border_color" => array(
					"title" => esc_html__("Border color", 'healthcoach'),
					"desc" => wp_kses_data( __("Border color for all skills items (only for type=pie)", 'healthcoach') ),
					"dependency" => array(
						'type' => array('pie')
					),
					"value" => "",
					"type" => "color"
				),
				"align" => array(
					"title" => esc_html__("Align skills block", 'healthcoach'),
					"desc" => wp_kses_data( __("Align skills block to left or right side", 'healthcoach') ),
					"value" => "",
					"type" => "checklist",
					"dir" => "horizontal",
					"options" => healthcoach_get_sc_param('float')
				), 
				"arc_caption" => array(
					"title" => esc_html__("Arc Caption", 'healthcoach'),
					"desc" => wp_kses_data( __("Arc caption - text in the center of the diagram", 'healthcoach') ),
					"dependency" => array(
						'type' => array('arc')
					),
					"value" => "",
					"type" => "text"
				),
				"pie_compact" => array(
					"title" => esc_html__("Pie compact", 'healthcoach'),
					"desc" => wp_kses_data( __("Show all skills in one diagram or as separate diagrams", 'healthcoach') ),
					"dependency" => array(
						'type' => array('pie')
					),
					"value" => "yes",
					"type" => "switch",
					"options" => healthcoach_get_sc_param('yes_no')
				),
				"pie_cutout" => array(
					"title" => esc_html__("Pie cutout", 'healthcoach'),
					"desc" => wp_kses_data( __("Pie cutout (0-99). 0 - without cutout, 99 - max cutout", 'healthcoach') ),
					"dependency" => array(
						'type' => array('pie')
					),
					"value" => 0,
					"min" => 0,
					"max" => 99,
					"type" => "spinner"
				),
				"title" => array(
					"title" => esc_html__("Title", 'healthcoach'),
					"desc" => wp_kses_data( __("Title for the block", 'healthcoach') ),
					"value" => "",
					"type" => "text"
				),
				"subtitle" => array(
					"title" => esc_html__("Subtitle", 'healthcoach'),
					"desc" => wp_kses_data( __("Subtitle for the block", 'healthcoach') ),
					"value" => "",
					"type" => "text"
				),
				"description" => array(
					"title" => esc_html__("Description", 'healthcoach'),
					"desc" => wp_kses_data( __("Short description for the block", 'healthcoach') ),
					"value" => "",
					"type" => "textarea"
				),
				"link" => array(
					"title" => esc_html__("Button URL", 'healthcoach'),
					"desc" => wp_kses_data( __("Link URL for the button at the bottom of the block", 'healthcoach') ),
					"value" => "",
					"type" => "text"
				),
				"link_caption" => array(
					"title" => esc_html__("Button caption", 'healthcoach'),
					"desc" => wp_kses_data( __("Caption for the button at the bottom of the block", 'healthcoach') ),
					"value" => "",
					"type" => "text"
				),
				"width" => healthcoach_shortcodes_width(),
				"height" => healthcoach_shortcodes_height(),
				"top" => healthcoach_get_sc_param('top'),
				"bottom" => healthcoach_get_sc_param('bottom'),
				"left" => healthcoach_get_sc_param('left'),
				"right" => healthcoach_get_sc_param('right'),
				"id" => healthcoach_get_sc_param('id'),
				"class" => healthcoach_get_sc_param('class'),
				"animation" => healthcoach_get_sc_param('animation'),
				"css" => healthcoach_get_sc_param('css')
			),
			"children" => array(
				"name" => "trx_skills_item",
				"title" => esc_html__("Skill", 'healthcoach'),
				"desc" => wp_kses_data( __("Skills item", 'healthcoach') ),
				"container" => false,
				"params" => array(
					"title" => array(
						"title" => esc_html__("Title", 'healthcoach'),
						"desc" => wp_kses_data( __("Current skills item title", 'healthcoach') ),
						"value" => "",
						"type" => "text"
					),
					"value" => array(
						"title" => esc_html__("Value", 'healthcoach'),
						"desc" => wp_kses_data( __("Current skills level", 'healthcoach') ),
						"value" => 50,
						"min" => 0,
						"step" => 1,
						"type" => "spinner"
					),
					"color" => array(
						"title" => esc_html__("Color", 'healthcoach'),
						"desc" => wp_kses_data( __("Current skills item color", 'healthcoach') ),
						"value" => "",
						"type" => "color"
					),
					"bg_color" => array(
						"title" => esc_html__("Background color", 'healthcoach'),
						"desc" => wp_kses_data( __("Current skills item background color (only for type=pie)", 'healthcoach') ),
						"value" => "",
						"type" => "color"
					),
					"border_color" => array(
						"title" => esc_html__("Border color", 'healthcoach'),
						"desc" => wp_kses_data( __("Current skills item border color (only for type=pie)", 'healthcoach') ),
						"value" => "",
						"type" => "color"
					),
					"style" => array(
						"title" => esc_html__("Counter style", 'healthcoach'),
						"desc" => wp_kses_data( __("Select style for the current skills item (only for type=counter)", 'healthcoach') ),
						"value" => 1,
						"options" => healthcoach_get_list_styles(1, 4),
						"type" => "checklist"
					), 
					"icon" => array(
						"title" => esc_html__("Counter icon",  'healthcoach'),
						"desc" => wp_kses_data( __('Select icon from Fontello icons set, placed above counter (only for type=counter)',  'healthcoach') ),
						"value" => "",
						"type" => "icons",
						"options" => healthcoach_get_sc_param('icons')
					),
					"id" => healthcoach_get_sc_param('id'),
					"class" => healthcoach_get_sc_param('class'),
					"css" => healthcoach_get_sc_param('css')
				)
			)
		));
	}
}


/* Register shortcode in the VC Builder
-------------------------------------------------------------------- */
if ( !function_exists( 'healthcoach_sc_skills_reg_shortcodes_vc' ) ) {
	//add_action('healthcoach_action_shortcodes_list_vc', 'healthcoach_sc_skills_reg_shortcodes_vc');
	function healthcoach_sc_skills_reg_shortcodes_vc() {
	
		vc_map( array(
			"base" => "trx_skills",
			"name" => esc_html__("Skills", 'healthcoach'),
			"description" => wp_kses_data( __("Insert skills diagramm", 'healthcoach') ),
			"category" => esc_html__('Content', 'healthcoach'),
			'icon' => 'icon_trx_skills',
			"class" => "trx_sc_collection trx_sc_skills",
			"content_element" => true,
			"is_container" => true,
			"show_settings_on_create" => true,
			"as_parent" => array('only' => 'trx_skills_item'),
			"params" => array(
				array(
					"param_name" => "max_value",
					"heading" => esc_html__("Max value", 'healthcoach'),
					"description" => wp_kses_data( __("Max value for skills items", 'healthcoach') ),
					"admin_label" => true,
					"class" => "",
					"value" => "100",
					"type" => "textfield"
				),
				array(
					"param_name" => "type",
					"heading" => esc_html__("Skills type", 'healthcoach'),
					"description" => wp_kses_data( __("Select type of skills block", 'healthcoach') ),
					"admin_label" => true,
					"class" => "",
					"value" => array(
						esc_html__('Bar', 'healthcoach') => 'bar',
						esc_html__('Pie chart', 'healthcoach') => 'pie',
						esc_html__('Counter', 'healthcoach') => 'counter',
						esc_html__('Arc', 'healthcoach') => 'arc'
					),
					"type" => "dropdown"
				),
				array(
					"param_name" => "layout",
					"heading" => esc_html__("Skills layout", 'healthcoach'),
					"description" => wp_kses_data( __("Select layout of skills block", 'healthcoach') ),
					"admin_label" => true,
					'dependency' => array(
						'element' => 'type',
						'value' => array('counter','bar','pie')
					),
					"class" => "",
					"value" => array(
						esc_html__('Rows', 'healthcoach') => 'rows',
						esc_html__('Columns', 'healthcoach') => 'columns'
					),
					"type" => "dropdown"
				),
				array(
					"param_name" => "dir",
					"heading" => esc_html__("Direction", 'healthcoach'),
					"description" => wp_kses_data( __("Select direction of skills block", 'healthcoach') ),
					"admin_label" => true,
					"class" => "",
					"value" => array_flip(healthcoach_get_sc_param('dir')),
					"type" => "dropdown"
				),
				array(
					"param_name" => "style",
					"heading" => esc_html__("Counters style", 'healthcoach'),
					"description" => wp_kses_data( __("Select style of skills items (only for type=counter)", 'healthcoach') ),
					"admin_label" => true,
					"class" => "",
					"value" => array_flip(healthcoach_get_list_styles(1, 4)),
					'dependency' => array(
						'element' => 'type',
						'value' => array('counter')
					),
					"type" => "dropdown"
				),
				array(
					"param_name" => "columns",
					"heading" => esc_html__("Columns count", 'healthcoach'),
					"description" => wp_kses_data( __("Skills columns count (required)", 'healthcoach') ),
					"admin_label" => true,
					"class" => "",
					"value" => "",
					"type" => "textfield"
				),
				array(
					"param_name" => "color",
					"heading" => esc_html__("Color", 'healthcoach'),
					"description" => wp_kses_data( __("Color for all skills items", 'healthcoach') ),
					"class" => "",
					"value" => "",
					"type" => "colorpicker"
				),
				array(
					"param_name" => "bg_color",
					"heading" => esc_html__("Background color", 'healthcoach'),
					"description" => wp_kses_data( __("Background color for all skills items (only for type=pie)", 'healthcoach') ),
					'dependency' => array(
						'element' => 'type',
						'value' => array('pie')
					),
					"class" => "",
					"value" => "",
					"type" => "colorpicker"
				),
				array(
					"param_name" => "border_color",
					"heading" => esc_html__("Border color", 'healthcoach'),
					"description" => wp_kses_data( __("Border color for all skills items (only for type=pie)", 'healthcoach') ),
					'dependency' => array(
						'element' => 'type',
						'value' => array('pie')
					),
					"class" => "",
					"value" => "",
					"type" => "colorpicker"
				),
				array(
					"param_name" => "align",
					"heading" => esc_html__("Alignment", 'healthcoach'),
					"description" => wp_kses_data( __("Align skills block to left or right side", 'healthcoach') ),
					"class" => "",
					"value" => array_flip(healthcoach_get_sc_param('float')),
					"type" => "dropdown"
				),
				array(
					"param_name" => "arc_caption",
					"heading" => esc_html__("Arc caption", 'healthcoach'),
					"description" => wp_kses_data( __("Arc caption - text in the center of the diagram", 'healthcoach') ),
					'dependency' => array(
						'element' => 'type',
						'value' => array('arc')
					),
					"class" => "",
					"value" => "",
					"type" => "textfield"
				),
				array(
					"param_name" => "pie_compact",
					"heading" => esc_html__("Pie compact", 'healthcoach'),
					"description" => wp_kses_data( __("Show all skills in one diagram or as separate diagrams", 'healthcoach') ),
					'dependency' => array(
						'element' => 'type',
						'value' => array('pie')
					),
					"class" => "",
					"value" => array(esc_html__('Show separate skills', 'healthcoach') => 'no'),
					"type" => "checkbox"
				),
				array(
					"param_name" => "pie_cutout",
					"heading" => esc_html__("Pie cutout", 'healthcoach'),
					"description" => wp_kses_data( __("Pie cutout (0-99). 0 - without cutout, 99 - max cutout", 'healthcoach') ),
					'dependency' => array(
						'element' => 'type',
						'value' => array('pie')
					),
					"class" => "",
					"value" => "",
					"type" => "textfield"
				),
				array(
					"param_name" => "title",
					"heading" => esc_html__("Title", 'healthcoach'),
					"description" => wp_kses_data( __("Title for the block", 'healthcoach') ),
					"admin_label" => true,
					"group" => esc_html__('Captions', 'healthcoach'),
					"class" => "",
					"value" => "",
					"type" => "textfield"
				),
				array(
					"param_name" => "subtitle",
					"heading" => esc_html__("Subtitle", 'healthcoach'),
					"description" => wp_kses_data( __("Subtitle for the block", 'healthcoach') ),
					"group" => esc_html__('Captions', 'healthcoach'),
					"class" => "",
					"value" => "",
					"type" => "textfield"
				),
				array(
					"param_name" => "description",
					"heading" => esc_html__("Description", 'healthcoach'),
					"description" => wp_kses_data( __("Description for the block", 'healthcoach') ),
					"group" => esc_html__('Captions', 'healthcoach'),
					"class" => "",
					"value" => "",
					"type" => "textarea"
				),
				array(
					"param_name" => "link",
					"heading" => esc_html__("Button URL", 'healthcoach'),
					"description" => wp_kses_data( __("Link URL for the button at the bottom of the block", 'healthcoach') ),
					"group" => esc_html__('Captions', 'healthcoach'),
					"class" => "",
					"value" => "",
					"type" => "textfield"
				),
				array(
					"param_name" => "link_caption",
					"heading" => esc_html__("Button caption", 'healthcoach'),
					"description" => wp_kses_data( __("Caption for the button at the bottom of the block", 'healthcoach') ),
					"group" => esc_html__('Captions', 'healthcoach'),
					"class" => "",
					"value" => "",
					"type" => "textfield"
				),
				healthcoach_get_vc_param('id'),
				healthcoach_get_vc_param('class'),
				healthcoach_get_vc_param('animation'),
				healthcoach_get_vc_param('css'),
				healthcoach_vc_width(),
				healthcoach_vc_height(),
				healthcoach_get_vc_param('margin_top'),
				healthcoach_get_vc_param('margin_bottom'),
				healthcoach_get_vc_param('margin_left'),
				healthcoach_get_vc_param('margin_right')
			)
		) );
		
		
		vc_map( array(
			"base" => "trx_skills_item",
			"name" => esc_html__("Skill", 'healthcoach'),
			"description" => wp_kses_data( __("Skills item", 'healthcoach') ),
			"show_settings_on_create" => true,
			'icon' => 'icon_trx_skills_item',
			"class" => "trx_sc_single trx_sc_skills_item",
			"content_element" => true,
			"is_container" => false,
			"as_child" => array('only' => 'trx_skills'),
			"as_parent" => array('except' => 'trx_skills'),
			"params" => array(
				array(
					"param_name" => "title",
					"heading" => esc_html__("Title", 'healthcoach'),
					"description" => wp_kses_data( __("Title for the current skills item", 'healthcoach') ),
					"admin_label" => true,
					"class" => "",
					"value" => "",
					"type" => "textfield"
				),
				array(
					"param_name" => "value",
					"heading" => esc_html__("Value", 'healthcoach'),
					"description" => wp_kses_data( __("Value for the current skills item", 'healthcoach') ),
					"admin_label" => true,
					"class" => "",
					"value" => "",
					"type" => "textfield"
				),
				array(
					"param_name" => "color",
					"heading" => esc_html__("Color", 'healthcoach'),
					"description" => wp_kses_data( __("Color for current skills item", 'healthcoach') ),
					"admin_label" => true,
					"class" => "",
					"value" => "",
					"type" => "colorpicker"
				),
				array(
					"param_name" => "bg_color",
					"heading" => esc_html__("Background color", 'healthcoach'),
					"description" => wp_kses_data( __("Background color for current skills item (only for type=pie)", 'healthcoach') ),
					"admin_label" => true,
					"class" => "",
					"value" => "",
					"type" => "colorpicker"
				),
				array(
					"param_name" => "border_color",
					"heading" => esc_html__("Border color", 'healthcoach'),
					"description" => wp_kses_data( __("Border color for current skills item (only for type=pie)", 'healthcoach') ),
					"class" => "",
					"value" => "",
					"type" => "colorpicker"
				),
				array(
					"param_name" => "style",
					"heading" => esc_html__("Counter style", 'healthcoach'),
					"description" => wp_kses_data( __("Select style for the current skills item (only for type=counter)", 'healthcoach') ),
					"admin_label" => true,
					"class" => "",
					"value" => array_flip(healthcoach_get_list_styles(1, 4)),
					"type" => "dropdown"
				),
				array(
					"param_name" => "icon",
					"heading" => esc_html__("Counter icon", 'healthcoach'),
					"description" => wp_kses_data( __("Select icon from Fontello icons set, placed before counter (only for type=counter)", 'healthcoach') ),
					"class" => "",
					"value" => healthcoach_get_sc_param('icons'),
					"type" => "dropdown"
				),
				healthcoach_get_vc_param('id'),
				healthcoach_get_vc_param('class'),
				healthcoach_get_vc_param('css'),
			)
		) );
		
		class WPBakeryShortCode_Trx_Skills extends HEALTHCOACH_VC_ShortCodeCollection {}
		class WPBakeryShortCode_Trx_Skills_Item extends HEALTHCOACH_VC_ShortCodeSingle {}
	}
}
?>