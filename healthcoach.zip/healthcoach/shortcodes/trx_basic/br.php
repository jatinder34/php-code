<?php

/* Theme setup section
-------------------------------------------------------------------- */
if (!function_exists('healthcoach_sc_br_theme_setup')) {
	add_action( 'healthcoach_action_before_init_theme', 'healthcoach_sc_br_theme_setup' );
	function healthcoach_sc_br_theme_setup() {
		add_action('healthcoach_action_shortcodes_list', 		'healthcoach_sc_br_reg_shortcodes');
	}
}



/* Shortcode implementation
-------------------------------------------------------------------- */

/*
[trx_br clear="left|right|both"]
*/

if (!function_exists('healthcoach_sc_br')) {	
	function healthcoach_sc_br($atts, $content = null) {
		if (healthcoach_in_shortcode_blogger()) return '';
		extract(healthcoach_html_decode(shortcode_atts(array(
			"clear" => ""
		), $atts)));
		$output = in_array($clear, array('left', 'right', 'both', 'all')) 
			? '<div class="clearfix" style="clear:' . str_replace('all', 'both', $clear) . '"></div>'
			: '<br />';
		return apply_filters('healthcoach_shortcode_output', $output, 'trx_br', $atts, $content);
	}
	healthcoach_require_shortcode("trx_br", "healthcoach_sc_br");
}



/* Register shortcode in the internal SC Builder
-------------------------------------------------------------------- */
if ( !function_exists( 'healthcoach_sc_br_reg_shortcodes' ) ) {
	//add_action('healthcoach_action_shortcodes_list', 'healthcoach_sc_br_reg_shortcodes');
	function healthcoach_sc_br_reg_shortcodes() {
	
		healthcoach_sc_map("trx_br", array(
			"title" => esc_html__("Break", 'healthcoach'),
			"desc" => wp_kses_data( __("Line break with clear floating (if need)", 'healthcoach') ),
			"decorate" => false,
			"container" => false,
			"params" => array(
				"clear" => 	array(
					"title" => esc_html__("Clear floating", 'healthcoach'),
					"desc" => wp_kses_data( __("Clear floating (if need)", 'healthcoach') ),
					"value" => "",
					"type" => "checklist",
					"options" => array(
						'none' => esc_html__('None', 'healthcoach'),
						'left' => esc_html__('Left', 'healthcoach'),
						'right' => esc_html__('Right', 'healthcoach'),
						'both' => esc_html__('Both', 'healthcoach')
					)
				)
			)
		));
	}
}
?>