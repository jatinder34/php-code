<?php

/* Theme setup section
-------------------------------------------------------------------- */
if (!function_exists('healthcoach_sc_title_theme_setup')) {
	add_action( 'healthcoach_action_before_init_theme', 'healthcoach_sc_title_theme_setup' );
	function healthcoach_sc_title_theme_setup() {
		add_action('healthcoach_action_shortcodes_list', 		'healthcoach_sc_title_reg_shortcodes');
		if (function_exists('healthcoach_exists_visual_composer') && healthcoach_exists_visual_composer())
			add_action('healthcoach_action_shortcodes_list_vc','healthcoach_sc_title_reg_shortcodes_vc');
	}
}



/* Shortcode implementation
-------------------------------------------------------------------- */

/*
[trx_title id="unique_id" style='regular|iconed' icon='' image='' background="on|off" type="1-6"]Et adipiscing integer, scelerisque pid, augue mus vel tincidunt porta[/trx_title]
*/

if (!function_exists('healthcoach_sc_title')) {	
	function healthcoach_sc_title($atts, $content=null){	
		if (healthcoach_in_shortcode_blogger()) return '';
		extract(healthcoach_html_decode(shortcode_atts(array(
			// Individual params
			"type" => "1",
			"style" => "regular",
			"align" => "",
			"font_weight" => "",
			"font_size" => "",
			"color" => "",
			"icon" => "",
			"image" => "",
			"picture" => "",
			"image_size" => "small",
			"position" => "left",
			// Common params
			"id" => "",
			"class" => "",
			"animation" => "",
			"css" => "",
			"width" => "",
			"top" => "",
			"bottom" => "",
			"left" => "",
			"right" => ""
		), $atts)));
		$class .= ($class ? ' ' : '') . healthcoach_get_css_position_as_classes($top, $right, $bottom, $left);
		$css .= healthcoach_get_css_dimensions_from_values($width)
			.($align && $align!='none' && !healthcoach_param_is_inherit($align) ? 'text-align:' . esc_attr($align) .';' : '')
			.($color ? 'color:' . esc_attr($color) .';' : '')
			.($font_weight && !healthcoach_param_is_inherit($font_weight) ? 'font-weight:' . esc_attr($font_weight) .';' : '')
			.($font_size   ? 'font-size:' . esc_attr($font_size) .';' : '')
			;
		$type = min(6, max(1, $type));
		if ($picture > 0) {
			$attach = wp_get_attachment_image_src( $picture, 'full' );
			if (isset($attach[0]) && $attach[0]!='')
				$picture = $attach[0];
		}
		$pic = $style!='iconed' 
			? '' 
			: '<span class="sc_title_icon sc_title_icon_'.esc_attr($position).'  sc_title_icon_'.esc_attr($image_size).($icon!='' && $icon!='none' ? ' '.esc_attr($icon) : '').'"'.'>'
				.($picture ? '<img src="'.esc_url($picture).'" alt="" />' : '')
				.(empty($picture) && $image && $image!='none' ? '<img src="'.esc_url(healthcoach_strpos($image, 'http')===0 ? $image : healthcoach_get_file_url('images/icons/'.($image).'.png')).'" alt="" />' : '')
				.'</span>';
		$output = '<h' . esc_attr($type) . ($id ? ' id="'.esc_attr($id).'"' : '')
				. ' class="sc_title sc_title_'.esc_attr($style)
					.($align && $align!='none' && !healthcoach_param_is_inherit($align) ? ' sc_align_' . esc_attr($align) : '')
					.(!empty($class) ? ' '.esc_attr($class) : '')
					.'"'
				. ($css!='' ? ' style="'.esc_attr($css).'"' : '')
				. (!healthcoach_param_is_off($animation) ? ' data-animation="'.esc_attr(healthcoach_get_animation_classes($animation)).'"' : '')
				. '>'
					. ($pic)
					. ($style=='divider' ? '<span class="sc_title_divider_before"'.($color ? ' style="background-color: '.esc_attr($color).'"' : '').'></span>' : '')
					. do_shortcode($content) 
					. ($style=='divider' ? '<span class="sc_title_divider_after"'.($color ? ' style="background-color: '.esc_attr($color).'"' : '').'></span>' : '')
				. '</h' . esc_attr($type) . '>';
		return apply_filters('healthcoach_shortcode_output', $output, 'trx_title', $atts, $content);
	}
	healthcoach_require_shortcode('trx_title', 'healthcoach_sc_title');
}



/* Register shortcode in the internal SC Builder
-------------------------------------------------------------------- */
if ( !function_exists( 'healthcoach_sc_title_reg_shortcodes' ) ) {
	//add_action('healthcoach_action_shortcodes_list', 'healthcoach_sc_title_reg_shortcodes');
	function healthcoach_sc_title_reg_shortcodes() {
	
		healthcoach_sc_map("trx_title", array(
			"title" => esc_html__("Title", 'healthcoach'),
			"desc" => wp_kses_data( __("Create header tag (1-6 level) with many styles", 'healthcoach') ),
			"decorate" => false,
			"container" => true,
			"params" => array(
				"_content_" => array(
					"title" => esc_html__("Title content", 'healthcoach'),
					"desc" => wp_kses_data( __("Title content", 'healthcoach') ),
					"rows" => 4,
					"value" => "",
					"type" => "textarea"
				),
				"type" => array(
					"title" => esc_html__("Title type", 'healthcoach'),
					"desc" => wp_kses_data( __("Title type (header level)", 'healthcoach') ),
					"divider" => true,
					"value" => "1",
					"type" => "select",
					"options" => array(
						'1' => esc_html__('Header 1', 'healthcoach'),
						'2' => esc_html__('Header 2', 'healthcoach'),
						'3' => esc_html__('Header 3', 'healthcoach'),
						'4' => esc_html__('Header 4', 'healthcoach'),
						'5' => esc_html__('Header 5', 'healthcoach'),
						'6' => esc_html__('Header 6', 'healthcoach'),
					)
				),
				"style" => array(
					"title" => esc_html__("Title style", 'healthcoach'),
					"desc" => wp_kses_data( __("Title style", 'healthcoach') ),
					"value" => "regular",
					"type" => "select",
					"options" => array(
						'regular' => esc_html__('Regular', 'healthcoach'),
						'underline' => esc_html__('Underline', 'healthcoach'),
						'divider' => esc_html__('Divider', 'healthcoach'),
						'iconed' => esc_html__('With icon (image)', 'healthcoach')
					)
				),
				"align" => array(
					"title" => esc_html__("Alignment", 'healthcoach'),
					"desc" => wp_kses_data( __("Title text alignment", 'healthcoach') ),
					"value" => "",
					"type" => "checklist",
					"dir" => "horizontal",
					"options" => healthcoach_get_sc_param('align')
				), 
				"font_size" => array(
					"title" => esc_html__("Font_size", 'healthcoach'),
					"desc" => wp_kses_data( __("Custom font size. If empty - use theme default", 'healthcoach') ),
					"value" => "",
					"type" => "text"
				),
				"font_weight" => array(
					"title" => esc_html__("Font weight", 'healthcoach'),
					"desc" => wp_kses_data( __("Custom font weight. If empty or inherit - use theme default", 'healthcoach') ),
					"value" => "",
					"type" => "select",
					"size" => "medium",
					"options" => array(
						'inherit' => esc_html__('Default', 'healthcoach'),
						'100' => esc_html__('Thin (100)', 'healthcoach'),
						'300' => esc_html__('Light (300)', 'healthcoach'),
						'400' => esc_html__('Normal (400)', 'healthcoach'),
						'600' => esc_html__('Semibold (600)', 'healthcoach'),
						'700' => esc_html__('Bold (700)', 'healthcoach'),
						'900' => esc_html__('Black (900)', 'healthcoach')
					)
				),
				"color" => array(
					"title" => esc_html__("Title color", 'healthcoach'),
					"desc" => wp_kses_data( __("Select color for the title", 'healthcoach') ),
					"value" => "",
					"type" => "color"
				),
				"icon" => array(
					"title" => esc_html__('Title font icon',  'healthcoach'),
					"desc" => wp_kses_data( __("Select font icon for the title from Fontello icons set (if style=iconed)",  'healthcoach') ),
					"dependency" => array(
						'style' => array('iconed')
					),
					"value" => "",
					"type" => "icons",
					"options" => healthcoach_get_sc_param('icons')
				),
				"image" => array(
					"title" => esc_html__('or image icon',  'healthcoach'),
					"desc" => wp_kses_data( __("Select image icon for the title instead icon above (if style=iconed)",  'healthcoach') ),
					"dependency" => array(
						'style' => array('iconed')
					),
					"value" => "",
					"type" => "images",
					"size" => "small",
					"options" => healthcoach_get_sc_param('images')
				),
				"picture" => array(
					"title" => esc_html__('or URL for image file', 'healthcoach'),
					"desc" => wp_kses_data( __("Select or upload image or write URL from other site (if style=iconed)", 'healthcoach') ),
					"dependency" => array(
						'style' => array('iconed')
					),
					"readonly" => false,
					"value" => "",
					"type" => "media"
				),
				"image_size" => array(
					"title" => esc_html__('Image (picture) size', 'healthcoach'),
					"desc" => wp_kses_data( __("Select image (picture) size (if style='iconed')", 'healthcoach') ),
					"dependency" => array(
						'style' => array('iconed')
					),
					"value" => "small",
					"type" => "checklist",
					"options" => array(
						'small' => esc_html__('Small', 'healthcoach'),
						'medium' => esc_html__('Medium', 'healthcoach'),
						'large' => esc_html__('Large', 'healthcoach')
					)
				),
				"position" => array(
					"title" => esc_html__('Icon (image) position', 'healthcoach'),
					"desc" => wp_kses_data( __("Select icon (image) position (if style=iconed)", 'healthcoach') ),
					"dependency" => array(
						'style' => array('iconed')
					),
					"value" => "left",
					"type" => "checklist",
					"options" => array(
						'top' => esc_html__('Top', 'healthcoach'),
						'left' => esc_html__('Left', 'healthcoach')
					)
				),
				"top" => healthcoach_get_sc_param('top'),
				"bottom" => healthcoach_get_sc_param('bottom'),
				"left" => healthcoach_get_sc_param('left'),
				"right" => healthcoach_get_sc_param('right'),
				"id" => healthcoach_get_sc_param('id'),
				"class" => healthcoach_get_sc_param('class'),
				"animation" => healthcoach_get_sc_param('animation'),
				"css" => healthcoach_get_sc_param('css')
			)
		));
	}
}


/* Register shortcode in the VC Builder
-------------------------------------------------------------------- */
if ( !function_exists( 'healthcoach_sc_title_reg_shortcodes_vc' ) ) {
	//add_action('healthcoach_action_shortcodes_list_vc', 'healthcoach_sc_title_reg_shortcodes_vc');
	function healthcoach_sc_title_reg_shortcodes_vc() {
	
		vc_map( array(
			"base" => "trx_title",
			"name" => esc_html__("Title", 'healthcoach'),
			"description" => wp_kses_data( __("Create header tag (1-6 level) with many styles", 'healthcoach') ),
			"category" => esc_html__('Content', 'healthcoach'),
			'icon' => 'icon_trx_title',
			"class" => "trx_sc_single trx_sc_title",
			"content_element" => true,
			"is_container" => false,
			"show_settings_on_create" => true,
			"params" => array(
				array(
					"param_name" => "content",
					"heading" => esc_html__("Title content", 'healthcoach'),
					"description" => wp_kses_data( __("Title content", 'healthcoach') ),
					"class" => "",
					"value" => "",
					"type" => "textarea_html"
				),
				array(
					"param_name" => "type",
					"heading" => esc_html__("Title type", 'healthcoach'),
					"description" => wp_kses_data( __("Title type (header level)", 'healthcoach') ),
					"admin_label" => true,
					"class" => "",
					"value" => array(
						esc_html__('Header 1', 'healthcoach') => '1',
						esc_html__('Header 2', 'healthcoach') => '2',
						esc_html__('Header 3', 'healthcoach') => '3',
						esc_html__('Header 4', 'healthcoach') => '4',
						esc_html__('Header 5', 'healthcoach') => '5',
						esc_html__('Header 6', 'healthcoach') => '6'
					),
					"type" => "dropdown"
				),
				array(
					"param_name" => "style",
					"heading" => esc_html__("Title style", 'healthcoach'),
					"description" => wp_kses_data( __("Title style: only text (regular) or with icon/image (iconed)", 'healthcoach') ),
					"admin_label" => true,
					"class" => "",
					"value" => array(
						esc_html__('Regular', 'healthcoach') => 'regular',
						esc_html__('Underline', 'healthcoach') => 'underline',
						esc_html__('Divider', 'healthcoach') => 'divider',
						esc_html__('With icon (image)', 'healthcoach') => 'iconed'
					),
					"type" => "dropdown"
				),
				array(
					"param_name" => "align",
					"heading" => esc_html__("Alignment", 'healthcoach'),
					"description" => wp_kses_data( __("Title text alignment", 'healthcoach') ),
					"admin_label" => true,
					"class" => "",
					"value" => array_flip(healthcoach_get_sc_param('align')),
					"type" => "dropdown"
				),
				array(
					"param_name" => "font_size",
					"heading" => esc_html__("Font size", 'healthcoach'),
					"description" => wp_kses_data( __("Custom font size. If empty - use theme default", 'healthcoach') ),
					"class" => "",
					"value" => "",
					"type" => "textfield"
				),
				array(
					"param_name" => "font_weight",
					"heading" => esc_html__("Font weight", 'healthcoach'),
					"description" => wp_kses_data( __("Custom font weight. If empty or inherit - use theme default", 'healthcoach') ),
					"class" => "",
					"value" => array(
						esc_html__('Default', 'healthcoach') => 'inherit',
						esc_html__('Thin (100)', 'healthcoach') => '100',
						esc_html__('Light (300)', 'healthcoach') => '300',
						esc_html__('Normal (400)', 'healthcoach') => '400',
						esc_html__('Semibold (600)', 'healthcoach') => '600',
						esc_html__('Bold (700)', 'healthcoach') => '700',
						esc_html__('Black (900)', 'healthcoach') => '900'
					),
					"type" => "dropdown"
				),
				array(
					"param_name" => "color",
					"heading" => esc_html__("Title color", 'healthcoach'),
					"description" => wp_kses_data( __("Select color for the title", 'healthcoach') ),
					"class" => "",
					"value" => "",
					"type" => "colorpicker"
				),
				array(
					"param_name" => "icon",
					"heading" => esc_html__("Title font icon", 'healthcoach'),
					"description" => wp_kses_data( __("Select font icon for the title from Fontello icons set (if style=iconed)", 'healthcoach') ),
					"class" => "",
					"group" => esc_html__('Icon &amp; Image', 'healthcoach'),
					'dependency' => array(
						'element' => 'style',
						'value' => array('iconed')
					),
					"value" => healthcoach_get_sc_param('icons'),
					"type" => "dropdown"
				),
				array(
					"param_name" => "image",
					"heading" => esc_html__("or image icon", 'healthcoach'),
					"description" => wp_kses_data( __("Select image icon for the title instead icon above (if style=iconed)", 'healthcoach') ),
					"class" => "",
					"group" => esc_html__('Icon &amp; Image', 'healthcoach'),
					'dependency' => array(
						'element' => 'style',
						'value' => array('iconed')
					),
					"value" => healthcoach_get_sc_param('images'),
					"type" => "dropdown"
				),
				array(
					"param_name" => "picture",
					"heading" => esc_html__("or select uploaded image", 'healthcoach'),
					"description" => wp_kses_data( __("Select or upload image or write URL from other site (if style=iconed)", 'healthcoach') ),
					"group" => esc_html__('Icon &amp; Image', 'healthcoach'),
					"class" => "",
					"value" => "",
					"type" => "attach_image"
				),
				array(
					"param_name" => "image_size",
					"heading" => esc_html__("Image (picture) size", 'healthcoach'),
					"description" => wp_kses_data( __("Select image (picture) size (if style=iconed)", 'healthcoach') ),
					"group" => esc_html__('Icon &amp; Image', 'healthcoach'),
					"class" => "",
					"value" => array(
						esc_html__('Small', 'healthcoach') => 'small',
						esc_html__('Medium', 'healthcoach') => 'medium',
						esc_html__('Large', 'healthcoach') => 'large'
					),
					"type" => "dropdown"
				),
				array(
					"param_name" => "position",
					"heading" => esc_html__("Icon (image) position", 'healthcoach'),
					"description" => wp_kses_data( __("Select icon (image) position (if style=iconed)", 'healthcoach') ),
					"group" => esc_html__('Icon &amp; Image', 'healthcoach'),
					"class" => "",
					"std" => "left",
					"value" => array(
						esc_html__('Top', 'healthcoach') => 'top',
						esc_html__('Left', 'healthcoach') => 'left'
					),
					"type" => "dropdown"
				),
				healthcoach_get_vc_param('id'),
				healthcoach_get_vc_param('class'),
				healthcoach_get_vc_param('animation'),
				healthcoach_get_vc_param('css'),
				healthcoach_get_vc_param('margin_top'),
				healthcoach_get_vc_param('margin_bottom'),
				healthcoach_get_vc_param('margin_left'),
				healthcoach_get_vc_param('margin_right')
			),
			'js_view' => 'VcTrxTextView'
		) );
		
		class WPBakeryShortCode_Trx_Title extends HEALTHCOACH_VC_ShortCodeSingle {}
	}
}
?>