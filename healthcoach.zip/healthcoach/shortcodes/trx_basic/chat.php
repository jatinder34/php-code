<?php

/* Theme setup section
-------------------------------------------------------------------- */
if (!function_exists('healthcoach_sc_chat_theme_setup')) {
	add_action( 'healthcoach_action_before_init_theme', 'healthcoach_sc_chat_theme_setup' );
	function healthcoach_sc_chat_theme_setup() {
		add_action('healthcoach_action_shortcodes_list', 		'healthcoach_sc_chat_reg_shortcodes');
		if (function_exists('healthcoach_exists_visual_composer') && healthcoach_exists_visual_composer())
			add_action('healthcoach_action_shortcodes_list_vc','healthcoach_sc_chat_reg_shortcodes_vc');
	}
}



/* Shortcode implementation
-------------------------------------------------------------------- */

/*
[trx_chat id="unique_id" link="url" title=""]Et adipiscing integer, scelerisque pid, augue mus vel tincidunt porta[/trx_chat]
[trx_chat id="unique_id" link="url" title=""]Et adipiscing integer, scelerisque pid, augue mus vel tincidunt porta[/trx_chat]
...
*/

if (!function_exists('healthcoach_sc_chat')) {	
	function healthcoach_sc_chat($atts, $content=null){	
		if (healthcoach_in_shortcode_blogger()) return '';
		extract(healthcoach_html_decode(shortcode_atts(array(
			// Individual params
			"photo" => "",
			"title" => "",
			"link" => "",
			// Common params
			"id" => "",
			"class" => "",
			"css" => "",
			"animation" => "",
			"width" => "",
			"height" => "",
			"top" => "",
			"bottom" => "",
			"left" => "",
			"right" => ""
		), $atts)));
		$class .= ($class ? ' ' : '') . healthcoach_get_css_position_as_classes($top, $right, $bottom, $left);
		$css .= healthcoach_get_css_dimensions_from_values($width, $height);
		$title = $title=='' ? $link : $title;
		if (!empty($photo)) {
			if ($photo > 0) {
				$attach = wp_get_attachment_image_src( $photo, 'full' );
				if (isset($attach[0]) && $attach[0]!='')
					$photo = $attach[0];
			}
			$photo = healthcoach_get_resized_image_tag($photo, 75, 75);
		}
		$content = do_shortcode($content);
		if (healthcoach_substr($content, 0, 2)!='<p') $content = '<p>' . ($content) . '</p>';
		$output = '<div' . ($id ? ' id="'.esc_attr($id).'"' : '') 
				. ' class="sc_chat' . (!empty($class) ? ' '.esc_attr($class) : '') . '"' 
				. (!healthcoach_param_is_off($animation) ? ' data-animation="'.esc_attr(healthcoach_get_animation_classes($animation)).'"' : '')
				. ($css ? ' style="'.esc_attr($css).'"' : '') 
				. '>'
				. ($photo ? '<div class="sc_chat_avatar">'.($photo).'</div>' : '')
					. '<div class="sc_chat_inner">'
						. ($title == '' ? '' : ('<div class="sc_chat_title">' . ($link!='' ? '<a href="'.esc_url($link).'">' : '') . ($title) . ($link!='' ? '</a>' : '') . '</div>'))
						. '<div class="sc_chat_content">'.($content).'</div>'
					. '</div>'
				. '</div>';
		return apply_filters('healthcoach_shortcode_output', $output, 'trx_chat', $atts, $content);
	}
	healthcoach_require_shortcode('trx_chat', 'healthcoach_sc_chat');
}



/* Register shortcode in the internal SC Builder
-------------------------------------------------------------------- */
if ( !function_exists( 'healthcoach_sc_chat_reg_shortcodes' ) ) {
	//add_action('healthcoach_action_shortcodes_list', 'healthcoach_sc_chat_reg_shortcodes');
	function healthcoach_sc_chat_reg_shortcodes() {
	
		healthcoach_sc_map("trx_chat", array(
			"title" => esc_html__("Chat", 'healthcoach'),
			"desc" => wp_kses_data( __("Chat message", 'healthcoach') ),
			"decorate" => true,
			"container" => true,
			"params" => array(
				"title" => array(
					"title" => esc_html__("Item title", 'healthcoach'),
					"desc" => wp_kses_data( __("Chat item title", 'healthcoach') ),
					"value" => "",
					"type" => "text"
				),
				"photo" => array(
					"title" => esc_html__("Item photo", 'healthcoach'),
					"desc" => wp_kses_data( __("Select or upload image or write URL from other site for the item photo (avatar)", 'healthcoach') ),
					"readonly" => false,
					"value" => "",
					"type" => "media"
				),
				"link" => array(
					"title" => esc_html__("Item link", 'healthcoach'),
					"desc" => wp_kses_data( __("Chat item link", 'healthcoach') ),
					"value" => "",
					"type" => "text"
				),
				"_content_" => array(
					"title" => esc_html__("Chat item content", 'healthcoach'),
					"desc" => wp_kses_data( __("Current chat item content", 'healthcoach') ),
					"rows" => 4,
					"value" => "",
					"type" => "textarea"
				),
				"width" => healthcoach_shortcodes_width(),
				"height" => healthcoach_shortcodes_height(),
				"top" => healthcoach_get_sc_param('top'),
				"bottom" => healthcoach_get_sc_param('bottom'),
				"left" => healthcoach_get_sc_param('left'),
				"right" => healthcoach_get_sc_param('right'),
				"id" => healthcoach_get_sc_param('id'),
				"class" => healthcoach_get_sc_param('class'),
				"animation" => healthcoach_get_sc_param('animation'),
				"css" => healthcoach_get_sc_param('css')
			)
		));
	}
}


/* Register shortcode in the VC Builder
-------------------------------------------------------------------- */
if ( !function_exists( 'healthcoach_sc_chat_reg_shortcodes_vc' ) ) {
	//add_action('healthcoach_action_shortcodes_list_vc', 'healthcoach_sc_chat_reg_shortcodes_vc');
	function healthcoach_sc_chat_reg_shortcodes_vc() {
	
		vc_map( array(
			"base" => "trx_chat",
			"name" => esc_html__("Chat", 'healthcoach'),
			"description" => wp_kses_data( __("Chat message", 'healthcoach') ),
			"category" => esc_html__('Content', 'healthcoach'),
			'icon' => 'icon_trx_chat',
			"class" => "trx_sc_container trx_sc_chat",
			"content_element" => true,
			"is_container" => true,
			"show_settings_on_create" => true,
			"params" => array(
				array(
					"param_name" => "title",
					"heading" => esc_html__("Item title", 'healthcoach'),
					"description" => wp_kses_data( __("Title for current chat item", 'healthcoach') ),
					"admin_label" => true,
					"class" => "",
					"value" => "",
					"type" => "textfield"
				),
				array(
					"param_name" => "photo",
					"heading" => esc_html__("Item photo", 'healthcoach'),
					"description" => wp_kses_data( __("Select or upload image or write URL from other site for the item photo (avatar)", 'healthcoach') ),
					"class" => "",
					"value" => "",
					"type" => "attach_image"
				),
				array(
					"param_name" => "link",
					"heading" => esc_html__("Link URL", 'healthcoach'),
					"description" => wp_kses_data( __("URL for the link on chat title click", 'healthcoach') ),
					"class" => "",
					"value" => "",
					"type" => "textfield"
				),
				healthcoach_get_vc_param('id'),
				healthcoach_get_vc_param('class'),
				healthcoach_get_vc_param('animation'),
				healthcoach_get_vc_param('css'),
				healthcoach_vc_width(),
				healthcoach_vc_height(),
				healthcoach_get_vc_param('margin_top'),
				healthcoach_get_vc_param('margin_bottom'),
				healthcoach_get_vc_param('margin_left'),
				healthcoach_get_vc_param('margin_right')
			),
			'js_view' => 'VcTrxTextContainerView'
		
		) );
		
		class WPBakeryShortCode_Trx_Chat extends HEALTHCOACH_VC_ShortCodeContainer {}
	}
}
?>