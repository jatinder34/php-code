<?php

/* Theme setup section
-------------------------------------------------------------------- */
if (!function_exists('healthcoach_sc_hide_theme_setup')) {
	add_action( 'healthcoach_action_before_init_theme', 'healthcoach_sc_hide_theme_setup' );
	function healthcoach_sc_hide_theme_setup() {
		add_action('healthcoach_action_shortcodes_list', 		'healthcoach_sc_hide_reg_shortcodes');
	}
}



/* Shortcode implementation
-------------------------------------------------------------------- */

/*
[trx_hide selector="unique_id"]
*/

if (!function_exists('healthcoach_sc_hide')) {	
	function healthcoach_sc_hide($atts, $content=null){	
		if (healthcoach_in_shortcode_blogger()) return '';
		extract(healthcoach_html_decode(shortcode_atts(array(
			// Individual params
			"selector" => "",
			"hide" => "on",
			"delay" => 0
		), $atts)));
		$selector = trim(chop($selector));
		if (!empty($selector)) {
			healthcoach_storage_concat('js_code', '
				'.($delay>0 ? 'setTimeout(function() {' : '').'
					jQuery("'.esc_attr($selector).'").' . ($hide=='on' ? 'hide' : 'show') . '();
				'.($delay>0 ? '},'.($delay).');' : '').'
			');
		}
		return apply_filters('healthcoach_shortcode_output', $output, 'trx_hide', $atts, $content);
	}
	healthcoach_require_shortcode('trx_hide', 'healthcoach_sc_hide');
}



/* Register shortcode in the internal SC Builder
-------------------------------------------------------------------- */
if ( !function_exists( 'healthcoach_sc_hide_reg_shortcodes' ) ) {
	//add_action('healthcoach_action_shortcodes_list', 'healthcoach_sc_hide_reg_shortcodes');
	function healthcoach_sc_hide_reg_shortcodes() {
	
		healthcoach_sc_map("trx_hide", array(
			"title" => esc_html__("Hide/Show any block", 'healthcoach'),
			"desc" => wp_kses_data( __("Hide or Show any block with desired CSS-selector", 'healthcoach') ),
			"decorate" => false,
			"container" => false,
			"params" => array(
				"selector" => array(
					"title" => esc_html__("Selector", 'healthcoach'),
					"desc" => wp_kses_data( __("Any block's CSS-selector", 'healthcoach') ),
					"value" => "",
					"type" => "text"
				),
				"hide" => array(
					"title" => esc_html__("Hide or Show", 'healthcoach'),
					"desc" => wp_kses_data( __("New state for the block: hide or show", 'healthcoach') ),
					"value" => "yes",
					"size" => "small",
					"options" => healthcoach_get_sc_param('yes_no'),
					"type" => "switch"
				)
			)
		));
	}
}
?>