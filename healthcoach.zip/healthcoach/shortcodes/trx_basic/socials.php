<?php

/* Theme setup section
-------------------------------------------------------------------- */
if (!function_exists('healthcoach_sc_socials_theme_setup')) {
	add_action( 'healthcoach_action_before_init_theme', 'healthcoach_sc_socials_theme_setup' );
	function healthcoach_sc_socials_theme_setup() {
		add_action('healthcoach_action_shortcodes_list', 		'healthcoach_sc_socials_reg_shortcodes');
		if (function_exists('healthcoach_exists_visual_composer') && healthcoach_exists_visual_composer())
			add_action('healthcoach_action_shortcodes_list_vc','healthcoach_sc_socials_reg_shortcodes_vc');
	}
}



/* Shortcode implementation
-------------------------------------------------------------------- */

/*
[trx_socials id="unique_id" size="small"]
	[trx_social_item name="facebook" url="profile url" icon="path for the icon"]
	[trx_social_item name="twitter" url="profile url"]
[/trx_socials]
*/

if (!function_exists('healthcoach_sc_socials')) {	
	function healthcoach_sc_socials($atts, $content=null){	
		if (healthcoach_in_shortcode_blogger()) return '';
		extract(healthcoach_html_decode(shortcode_atts(array(
			// Individual params
			"size" => "small",		// tiny | small | medium | large
			"shape" => "square",	// round | square
			"type" => healthcoach_get_theme_setting('socials_type'),	// icons | images
			"socials" => "",
			"custom" => "no",
			// Common params
			"id" => "",
			"class" => "",
			"animation" => "",
			"css" => "",
			"top" => "",
			"bottom" => "",
			"left" => "",
			"right" => ""
		), $atts)));
		$class .= ($class ? ' ' : '') . healthcoach_get_css_position_as_classes($top, $right, $bottom, $left);
		healthcoach_storage_set('sc_social_data', array(
			'icons' => false,
            'type' => $type
            )
        );
		if (!empty($socials)) {
			$allowed = explode('|', $socials);
			$list = array();
			for ($i=0; $i<count($allowed); $i++) {
				$s = explode('=', $allowed[$i]);
				if (!empty($s[1])) {
					$list[] = array(
						'icon'	=> $type=='images' ? healthcoach_get_socials_url($s[0]) : 'icon-'.trim($s[0]),
						'url'	=> $s[1]
						);
				}
			}
			if (count($list) > 0) healthcoach_storage_set_array('sc_social_data', 'icons', $list);
		} else if (healthcoach_param_is_on($custom))
			$content = do_shortcode($content);
		if (healthcoach_storage_get_array('sc_social_data', 'icons')===false) healthcoach_storage_set_array('sc_social_data', 'icons', healthcoach_get_custom_option('social_icons'));
		$output = healthcoach_prepare_socials(healthcoach_storage_get_array('sc_social_data', 'icons'));
		$output = $output
			? '<div' . ($id ? ' id="'.esc_attr($id).'"' : '') 
				. ' class="sc_socials sc_socials_type_' . esc_attr($type) . ' sc_socials_shape_' . esc_attr($shape) . ' sc_socials_size_' . esc_attr($size) . (!empty($class) ? ' '.esc_attr($class) : '') . '"' 
				. ($css!='' ? ' style="'.esc_attr($css).'"' : '') 
				. (!healthcoach_param_is_off($animation) ? ' data-animation="'.esc_attr(healthcoach_get_animation_classes($animation)).'"' : '')
				. '>' 
				. ($output)
				. '</div>'
			: '';
		return apply_filters('healthcoach_shortcode_output', $output, 'trx_socials', $atts, $content);
	}
	healthcoach_require_shortcode('trx_socials', 'healthcoach_sc_socials');
}


if (!function_exists('healthcoach_sc_social_item')) {	
	function healthcoach_sc_social_item($atts, $content=null){	
		if (healthcoach_in_shortcode_blogger()) return '';
		extract(healthcoach_html_decode(shortcode_atts(array(
			// Individual params
			"name" => "",
			"url" => "",
			"icon" => ""
		), $atts)));
		if (empty($icon)) {
			if (!empty($name)) {
				$type = healthcoach_storage_get_array('sc_social_data', 'type');
				if ($type=='images') {
					if (file_exists(healthcoach_get_socials_dir($name.'.png')))
						$icon = healthcoach_get_socials_url($name.'.png');
				} else
					$icon = 'icon-'.esc_attr($name);
			}
		} else if ((int) $icon > 0) {
			$attach = wp_get_attachment_image_src( $icon, 'full' );
			if (isset($attach[0]) && $attach[0]!='')
				$icon = $attach[0];
		}
		if (!empty($icon) && !empty($url)) {
			if (healthcoach_storage_get_array('sc_social_data', 'icons')===false) healthcoach_storage_set_array('sc_social_data', 'icons', array());
			healthcoach_storage_set_array2('sc_social_data', 'icons', '', array(
				'icon' => $icon,
				'url' => $url
				)
			);
		}
		return '';
	}
	healthcoach_require_shortcode('trx_social_item', 'healthcoach_sc_social_item');
}



/* Register shortcode in the internal SC Builder
-------------------------------------------------------------------- */
if ( !function_exists( 'healthcoach_sc_socials_reg_shortcodes' ) ) {
	//add_action('healthcoach_action_shortcodes_list', 'healthcoach_sc_socials_reg_shortcodes');
	function healthcoach_sc_socials_reg_shortcodes() {
	
		healthcoach_sc_map("trx_socials", array(
			"title" => esc_html__("Social icons", 'healthcoach'),
			"desc" => wp_kses_data( __("List of social icons (with hovers)", 'healthcoach') ),
			"decorate" => true,
			"container" => false,
			"params" => array(
				"type" => array(
					"title" => esc_html__("Icon's type", 'healthcoach'),
					"desc" => wp_kses_data( __("Type of the icons - images or font icons", 'healthcoach') ),
					"value" => healthcoach_get_theme_setting('socials_type'),
					"options" => array(
						'icons' => esc_html__('Icons', 'healthcoach'),
						'images' => esc_html__('Images', 'healthcoach')
					),
					"type" => "checklist"
				), 
				"size" => array(
					"title" => esc_html__("Icon's size", 'healthcoach'),
					"desc" => wp_kses_data( __("Size of the icons", 'healthcoach') ),
					"value" => "small",
					"options" => healthcoach_get_sc_param('sizes'),
					"type" => "checklist"
				), 
				"shape" => array(
					"title" => esc_html__("Icon's shape", 'healthcoach'),
					"desc" => wp_kses_data( __("Shape of the icons", 'healthcoach') ),
					"value" => "square",
					"options" => healthcoach_get_sc_param('shapes'),
					"type" => "checklist"
				), 
				"socials" => array(
					"title" => esc_html__("Manual socials list", 'healthcoach'),
					"desc" => wp_kses_data( __("Custom list of social networks. For example: twitter=http://twitter.com/my_profile|facebook=http://facebook.com/my_profile. If empty - use socials from Theme options.", 'healthcoach') ),
					"divider" => true,
					"value" => "",
					"type" => "text"
				),
				"custom" => array(
					"title" => esc_html__("Custom socials", 'healthcoach'),
					"desc" => wp_kses_data( __("Make custom icons from inner shortcodes (prepare it on tabs)", 'healthcoach') ),
					"divider" => true,
					"value" => "no",
					"options" => healthcoach_get_sc_param('yes_no'),
					"type" => "switch"
				),
				"top" => healthcoach_get_sc_param('top'),
				"bottom" => healthcoach_get_sc_param('bottom'),
				"left" => healthcoach_get_sc_param('left'),
				"right" => healthcoach_get_sc_param('right'),
				"id" => healthcoach_get_sc_param('id'),
				"class" => healthcoach_get_sc_param('class'),
				"animation" => healthcoach_get_sc_param('animation'),
				"css" => healthcoach_get_sc_param('css')
			),
			"children" => array(
				"name" => "trx_social_item",
				"title" => esc_html__("Custom social item", 'healthcoach'),
				"desc" => wp_kses_data( __("Custom social item: name, profile url and icon url", 'healthcoach') ),
				"decorate" => false,
				"container" => false,
				"params" => array(
					"name" => array(
						"title" => esc_html__("Social name", 'healthcoach'),
						"desc" => wp_kses_data( __("Name (slug) of the social network (twitter, facebook, linkedin, etc.)", 'healthcoach') ),
						"value" => "",
						"type" => "text"
					),
					"url" => array(
						"title" => esc_html__("Your profile URL", 'healthcoach'),
						"desc" => wp_kses_data( __("URL of your profile in specified social network", 'healthcoach') ),
						"value" => "",
						"type" => "text"
					),
					"icon" => array(
						"title" => esc_html__("URL (source) for icon file", 'healthcoach'),
						"desc" => wp_kses_data( __("Select or upload image or write URL from other site for the current social icon", 'healthcoach') ),
						"readonly" => false,
						"value" => "",
						"type" => "media"
					)
				)
			)
		));
	}
}


/* Register shortcode in the VC Builder
-------------------------------------------------------------------- */
if ( !function_exists( 'healthcoach_sc_socials_reg_shortcodes_vc' ) ) {
	//add_action('healthcoach_action_shortcodes_list_vc', 'healthcoach_sc_socials_reg_shortcodes_vc');
	function healthcoach_sc_socials_reg_shortcodes_vc() {
	
		vc_map( array(
			"base" => "trx_socials",
			"name" => esc_html__("Social icons", 'healthcoach'),
			"description" => wp_kses_data( __("Custom social icons", 'healthcoach') ),
			"category" => esc_html__('Content', 'healthcoach'),
			'icon' => 'icon_trx_socials',
			"class" => "trx_sc_collection trx_sc_socials",
			"content_element" => true,
			"is_container" => true,
			"show_settings_on_create" => true,
			"as_parent" => array('only' => 'trx_social_item'),
			"params" => array_merge(array(
				array(
					"param_name" => "type",
					"heading" => esc_html__("Icon's type", 'healthcoach'),
					"description" => wp_kses_data( __("Type of the icons - images or font icons", 'healthcoach') ),
					"class" => "",
					"std" => healthcoach_get_theme_setting('socials_type'),
					"value" => array(
						esc_html__('Icons', 'healthcoach') => 'icons',
						esc_html__('Images', 'healthcoach') => 'images'
					),
					"type" => "dropdown"
				),
				array(
					"param_name" => "size",
					"heading" => esc_html__("Icon's size", 'healthcoach'),
					"description" => wp_kses_data( __("Size of the icons", 'healthcoach') ),
					"class" => "",
					"std" => "small",
					"value" => array_flip(healthcoach_get_sc_param('sizes')),
					"type" => "dropdown"
				),
				array(
					"param_name" => "shape",
					"heading" => esc_html__("Icon's shape", 'healthcoach'),
					"description" => wp_kses_data( __("Shape of the icons", 'healthcoach') ),
					"class" => "",
					"std" => "square",
					"value" => array_flip(healthcoach_get_sc_param('shapes')),
					"type" => "dropdown"
				),
				array(
					"param_name" => "socials",
					"heading" => esc_html__("Manual socials list", 'healthcoach'),
					"description" => wp_kses_data( __("Custom list of social networks. For example: twitter=http://twitter.com/my_profile|facebook=http://facebook.com/my_profile. If empty - use socials from Theme options.", 'healthcoach') ),
					"class" => "",
					"value" => "",
					"type" => "textfield"
				),
				array(
					"param_name" => "custom",
					"heading" => esc_html__("Custom socials", 'healthcoach'),
					"description" => wp_kses_data( __("Make custom icons from inner shortcodes (prepare it on tabs)", 'healthcoach') ),
					"class" => "",
					"value" => array(esc_html__('Custom socials', 'healthcoach') => 'yes'),
					"type" => "checkbox"
				),
				healthcoach_get_vc_param('id'),
				healthcoach_get_vc_param('class'),
				healthcoach_get_vc_param('animation'),
				healthcoach_get_vc_param('css'),
				healthcoach_get_vc_param('margin_top'),
				healthcoach_get_vc_param('margin_bottom'),
				healthcoach_get_vc_param('margin_left'),
				healthcoach_get_vc_param('margin_right')
			))
		) );
		
		
		vc_map( array(
			"base" => "trx_social_item",
			"name" => esc_html__("Custom social item", 'healthcoach'),
			"description" => wp_kses_data( __("Custom social item: name, profile url and icon url", 'healthcoach') ),
			"show_settings_on_create" => true,
			"content_element" => true,
			"is_container" => false,
			'icon' => 'icon_trx_social_item',
			"class" => "trx_sc_single trx_sc_social_item",
			"as_child" => array('only' => 'trx_socials'),
			"as_parent" => array('except' => 'trx_socials'),
			"params" => array(
				array(
					"param_name" => "name",
					"heading" => esc_html__("Social name", 'healthcoach'),
					"description" => wp_kses_data( __("Name (slug) of the social network (twitter, facebook, linkedin, etc.)", 'healthcoach') ),
					"class" => "",
					"value" => "",
					"type" => "textfield"
				),
				array(
					"param_name" => "url",
					"heading" => esc_html__("Your profile URL", 'healthcoach'),
					"description" => wp_kses_data( __("URL of your profile in specified social network", 'healthcoach') ),
					"class" => "",
					"value" => "",
					"type" => "textfield"
				),
				array(
					"param_name" => "icon",
					"heading" => esc_html__("URL (source) for icon file", 'healthcoach'),
					"description" => wp_kses_data( __("Select or upload image or write URL from other site for the current social icon", 'healthcoach') ),
					"admin_label" => true,
					"class" => "",
					"value" => "",
					"type" => "attach_image"
				)
			)
		) );
		
		class WPBakeryShortCode_Trx_Socials extends HEALTHCOACH_VC_ShortCodeCollection {}
		class WPBakeryShortCode_Trx_Social_Item extends HEALTHCOACH_VC_ShortCodeSingle {}
	}
}
?>