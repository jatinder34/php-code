<?php

/* Theme setup section
-------------------------------------------------------------------- */
if (!function_exists('healthcoach_sc_infobox_theme_setup')) {
	add_action( 'healthcoach_action_before_init_theme', 'healthcoach_sc_infobox_theme_setup' );
	function healthcoach_sc_infobox_theme_setup() {
		add_action('healthcoach_action_shortcodes_list', 		'healthcoach_sc_infobox_reg_shortcodes');
		if (function_exists('healthcoach_exists_visual_composer') && healthcoach_exists_visual_composer())
			add_action('healthcoach_action_shortcodes_list_vc','healthcoach_sc_infobox_reg_shortcodes_vc');
	}
}



/* Shortcode implementation
-------------------------------------------------------------------- */

/*
[trx_infobox id="unique_id" style="regular|info|success|error|result" static="0|1"]Et adipiscing integer, scelerisque pid, augue mus vel tincidunt porta[/trx_infobox]
*/

if (!function_exists('healthcoach_sc_infobox')) {	
	function healthcoach_sc_infobox($atts, $content=null){	
		if (healthcoach_in_shortcode_blogger()) return '';
		extract(healthcoach_html_decode(shortcode_atts(array(
			// Individual params
			"style" => "regular",
			"closeable" => "no",
			"icon" => "",
			"color" => "",
			"bg_color" => "",
			// Common params
			"id" => "",
			"class" => "",
			"animation" => "",
			"css" => "",
			"top" => "",
			"bottom" => "",
			"left" => "",
			"right" => ""
		), $atts)));
		$class .= ($class ? ' ' : '') . healthcoach_get_css_position_as_classes($top, $right, $bottom, $left);
		$css .= ($color !== '' ? 'color:' . esc_attr($color) .';' : '')
			. ($bg_color !== '' ? 'background-color:' . esc_attr($bg_color) .';' : '');
		if (empty($icon)) {
			if ($style=='regular')
				$icon = 'icon-cog';
			else if ($style=='success')
				$icon = 'icon-check';
			else if ($style=='error')
				$icon = 'icon-attention';
			else if ($style=='info')
				$icon = 'icon-info';
		} else if ($icon=='none')
			$icon = '';

		$content = do_shortcode($content);
		$output = '<div' . ($id ? ' id="'.esc_attr($id).'"' : '') 
				. ' class="sc_infobox sc_infobox_style_' . esc_attr($style) 
					. (healthcoach_param_is_on($closeable) ? ' sc_infobox_closeable' : '') 
					. (!empty($class) ? ' '.esc_attr($class) : '') 
					. ($icon!='' && !healthcoach_param_is_inherit($icon) ? ' sc_infobox_iconed '. esc_attr($icon) : '') 
					. '"'
				. (!healthcoach_param_is_off($animation) ? ' data-animation="'.esc_attr(healthcoach_get_animation_classes($animation)).'"' : '')
				. ($css!='' ? ' style="'.esc_attr($css).'"' : '')
				. '>'
				. trim($content)
				. '</div>';
		return apply_filters('healthcoach_shortcode_output', $output, 'trx_infobox', $atts, $content);
	}
	healthcoach_require_shortcode('trx_infobox', 'healthcoach_sc_infobox');
}



/* Register shortcode in the internal SC Builder
-------------------------------------------------------------------- */
if ( !function_exists( 'healthcoach_sc_infobox_reg_shortcodes' ) ) {
	//add_action('healthcoach_action_shortcodes_list', 'healthcoach_sc_infobox_reg_shortcodes');
	function healthcoach_sc_infobox_reg_shortcodes() {
	
		healthcoach_sc_map("trx_infobox", array(
			"title" => esc_html__("Infobox", 'healthcoach'),
			"desc" => wp_kses_data( __("Insert infobox into your post (page)", 'healthcoach') ),
			"decorate" => false,
			"container" => true,
			"params" => array(
				"style" => array(
					"title" => esc_html__("Style", 'healthcoach'),
					"desc" => wp_kses_data( __("Infobox style", 'healthcoach') ),
					"value" => "regular",
					"type" => "checklist",
					"dir" => "horizontal",
					"options" => array(
						'regular' => esc_html__('Regular', 'healthcoach'),
						'info' => esc_html__('Info', 'healthcoach'),
						'success' => esc_html__('Success', 'healthcoach'),
						'error' => esc_html__('Error', 'healthcoach')
					)
				),
				"closeable" => array(
					"title" => esc_html__("Closeable box", 'healthcoach'),
					"desc" => wp_kses_data( __("Create closeable box (with close button)", 'healthcoach') ),
					"value" => "no",
					"type" => "switch",
					"options" => healthcoach_get_sc_param('yes_no')
				),
				"icon" => array(
					"title" => esc_html__("Custom icon",  'healthcoach'),
					"desc" => wp_kses_data( __('Select icon for the infobox from Fontello icons set. If empty - use default icon',  'healthcoach') ),
					"value" => "",
					"type" => "icons",
					"options" => healthcoach_get_sc_param('icons')
				),
				"color" => array(
					"title" => esc_html__("Text color", 'healthcoach'),
					"desc" => wp_kses_data( __("Any color for text and headers", 'healthcoach') ),
					"value" => "",
					"type" => "color"
				),
				"bg_color" => array(
					"title" => esc_html__("Background color", 'healthcoach'),
					"desc" => wp_kses_data( __("Any background color for this infobox", 'healthcoach') ),
					"value" => "",
					"type" => "color"
				),
				"_content_" => array(
					"title" => esc_html__("Infobox content", 'healthcoach'),
					"desc" => wp_kses_data( __("Content for infobox", 'healthcoach') ),
					"divider" => true,
					"rows" => 4,
					"value" => "",
					"type" => "textarea"
				),
				"top" => healthcoach_get_sc_param('top'),
				"bottom" => healthcoach_get_sc_param('bottom'),
				"left" => healthcoach_get_sc_param('left'),
				"right" => healthcoach_get_sc_param('right'),
				"id" => healthcoach_get_sc_param('id'),
				"class" => healthcoach_get_sc_param('class'),
				"animation" => healthcoach_get_sc_param('animation'),
				"css" => healthcoach_get_sc_param('css')
			)
		));
	}
}


/* Register shortcode in the VC Builder
-------------------------------------------------------------------- */
if ( !function_exists( 'healthcoach_sc_infobox_reg_shortcodes_vc' ) ) {
	//add_action('healthcoach_action_shortcodes_list_vc', 'healthcoach_sc_infobox_reg_shortcodes_vc');
	function healthcoach_sc_infobox_reg_shortcodes_vc() {
	
		vc_map( array(
			"base" => "trx_infobox",
			"name" => esc_html__("Infobox", 'healthcoach'),
			"description" => wp_kses_data( __("Box with info or error message", 'healthcoach') ),
			"category" => esc_html__('Content', 'healthcoach'),
			'icon' => 'icon_trx_infobox',
			"class" => "trx_sc_container trx_sc_infobox",
			"content_element" => true,
			"is_container" => true,
			"show_settings_on_create" => true,
			"params" => array(
				array(
					"param_name" => "style",
					"heading" => esc_html__("Style", 'healthcoach'),
					"description" => wp_kses_data( __("Infobox style", 'healthcoach') ),
					"admin_label" => true,
					"class" => "",
					"value" => array(
							esc_html__('Regular', 'healthcoach') => 'regular',
							esc_html__('Info', 'healthcoach') => 'info',
							esc_html__('Success', 'healthcoach') => 'success',
							esc_html__('Error', 'healthcoach') => 'error',
							esc_html__('Result', 'healthcoach') => 'result'
						),
					"type" => "dropdown"
				),
				array(
					"param_name" => "closeable",
					"heading" => esc_html__("Closeable", 'healthcoach'),
					"description" => wp_kses_data( __("Create closeable box (with close button)", 'healthcoach') ),
					"class" => "",
					"value" => array(esc_html__('Close button', 'healthcoach') => 'yes'),
					"type" => "checkbox"
				),
				array(
					"param_name" => "icon",
					"heading" => esc_html__("Custom icon", 'healthcoach'),
					"description" => wp_kses_data( __("Select icon for the infobox from Fontello icons set. If empty - use default icon", 'healthcoach') ),
					"class" => "",
					"value" => healthcoach_get_sc_param('icons'),
					"type" => "dropdown"
				),
				array(
					"param_name" => "color",
					"heading" => esc_html__("Text color", 'healthcoach'),
					"description" => wp_kses_data( __("Any color for the text and headers", 'healthcoach') ),
					"class" => "",
					"value" => "",
					"type" => "colorpicker"
				),
				array(
					"param_name" => "bg_color",
					"heading" => esc_html__("Background color", 'healthcoach'),
					"description" => wp_kses_data( __("Any background color for this infobox", 'healthcoach') ),
					"class" => "",
					"value" => "",
					"type" => "colorpicker"
				),
				healthcoach_get_vc_param('id'),
				healthcoach_get_vc_param('class'),
				healthcoach_get_vc_param('animation'),
				healthcoach_get_vc_param('css'),
				healthcoach_get_vc_param('margin_top'),
				healthcoach_get_vc_param('margin_bottom'),
				healthcoach_get_vc_param('margin_left'),
				healthcoach_get_vc_param('margin_right')
			),
			'js_view' => 'VcTrxTextContainerView'
		) );
		
		class WPBakeryShortCode_Trx_Infobox extends HEALTHCOACH_VC_ShortCodeContainer {}
	}
}
?>