<?php
/**
 * Attachment page
 */
get_header(); 

while ( have_posts() ) { the_post();

	// Move healthcoach_set_post_views to the javascript - counter will work under cache system
	if (healthcoach_get_custom_option('use_ajax_views_counter')=='no') {
		healthcoach_set_post_views(get_the_ID());
	}

	healthcoach_show_post_layout(
		array(
			'layout' => 'attachment',
			'sidebar' => !healthcoach_param_is_off(healthcoach_get_custom_option('show_sidebar_main'))
		)
	);

}

get_footer();
?>