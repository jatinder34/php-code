<?php
/*
 * The template for displaying "Page 404"
*/

// Disable direct call
if ( ! defined( 'ABSPATH' ) ) { exit; }


/* Theme setup section
-------------------------------------------------------------------- */

if ( !function_exists( 'healthcoach_template_404_theme_setup' ) ) {
	add_action( 'healthcoach_action_before_init_theme', 'healthcoach_template_404_theme_setup', 1 );
	function healthcoach_template_404_theme_setup() {
		healthcoach_add_template(array(
			'layout' => '404',
			'mode'   => 'internal',
			'title'  => 'Page 404',
			'theme_options' => array(
				'article_style' => 'stretch'
			)
		));
	}
}

// Template output
if ( !function_exists( 'healthcoach_template_404_output' ) ) {
	function healthcoach_template_404_output() {
		?>
		<article class="post_item post_item_404">
			<div class="post_content">
			<div class="image_404"><img class="background_cover" src="<?php echo esc_url(get_template_directory_uri()).'/images/404.png';?>"></div>
				<h2 class="page_subtitle"><?php esc_html_e('Can&rsquo;t find that page', 'healthcoach'); ?></h2>
				<h5 class="subtitle"><?php esc_html_e('ERROR 404', 'healthcoach'); ?></h5>
				<p class="page_description"><?php echo wp_kses( sprintf( __('Can\'t find what you need? Take a moment and do a<br>search below or start from <a href="%s">our homepage</a>.', 'healthcoach'), esc_url(home_url('/')) ), array('br' => array(), 'a' => array('href'=> array())) ); ?></p>
				<div class="page_search"><?php healthcoach_show_layout(healthcoach_sc_search(array('state'=>'fixed', 'title'=>__('To search type and hit enter', 'healthcoach')))); ?></div>
			</div>
		</article>
		<?php
	}
}
?>