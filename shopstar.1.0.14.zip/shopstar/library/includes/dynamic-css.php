<style type="text/css">

<?php
if ( $shopstar_slider_has_min_width ) {
?>

.slider-container.default .slider .slide img {
	min-width: <?php echo floatVal( $shopstar_slider_min_width ); ?>px;
}
	
<?php
}
?>

</style>